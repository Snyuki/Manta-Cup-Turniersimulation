package de.manta.black.turnierspagetti;

import java.awt.Dialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

import de.manta.black.turniersim.materialien.Spieler;
import de.manta.black.turniersim.materialien.Team;

/**
 * @version 05.04.2022
 * @author Jonas Müller
 *
 */
public class Simulation
{   
    
    private static final String HIGHLIGHTER = "-------------------------";

    /** The Tournament Service handling everything in a tournament */
    private TournamentService _tournamentService;
    
    // The Simulation GUI
    private Window _simulationWindow;
    private FileHandler _handler;
    private JFrame _frame;
    private DisplayWinnerDialog _displayFrame;

    private SwingWorker<Void, String> _worker;
    
    /**
     * Simulates the Tournament
     */
    public Simulation()
    {
        _simulationWindow = new Window();
        _handler = new FileHandler();
        _frame = new JFrame();
        
        _handler.setUpEnviroment();
        addListeners();
        _tournamentService = new TournamentService(_handler);
        _simulationWindow.showFrame();
    }

    /**
     * Creates the 12 Teams with each 8 Players
     */
    private Team[] createTeams()
    {
        Team[] teams = new Team[12];
        for(int i = 0; i < 12; i++) {
            teams[i] = createRandomTeam(i);
        }
       
        return teams;
    }
    
    /*
     * TODO Current Tasks
     * HOW Cancel und Resume Multisimulate
     * XXX Multi-simulation / log winners should show also all ko placements for the teams
     * XXX Tiebreaker bei den Brackets hinzufügen
     * HOW Write multisimulate to log after cancel
     * XXX Add Combobox for elo
     *      -> Tab übergreifende Checkbox zum umschalten zwischen Zahl und Combobox
     * XXX Multisimulate -> Wie oft hat jedes Team gegen ein anderes Team gewonnen / verloren
     * XXX Multisimulate -> Durchschnittliche Platzierung in der eigenen Gruppe
     * XXX Runtime des Programms zeigen
     * XXX Möglichkeit die Turnierart zu ändern (Mantacup V3)
     * XXX Teamanzahl als Konstante festhalten um Skalierbarkeit zu erreichen (Mantacup V3)
     * XXX MVP für Turnier vergeben
     *      -> Die besten 4 Teams haben jeweils eine absteigende Wahrscheinlichkeit den MVP zu erhalten
     *      -> Innerhalb des Teams gibt es eine sich nach der Spielerelo richtende Wahrscheinlichkeit den MVP zu erhalten
     * XXX Avg Elo update bei Programmstart
     * XXX Icons hochladen die neben dem Team angezeigt werden
     * XXX Add Wins of the Team to the Table representation
     */

    /**
     * @return A random generated Team with the name of the stringifined parameter
     */
    private Team createRandomTeam(int k)
    {
        Spieler[] lineup = new Spieler[8];
        for(int i = 0; i < 8; i++) {
            
            int j = (int) (8 + Math.random() * (23 - 8));
            lineup[i] = new Spieler(Integer.toString(j), j, "Rndm Position");            
        }
        Team team = new Team(lineup, "Team " + Integer.toString(k));
        String rdmName = "";
        for(int i = 0; i < 3; i++)
        {
            rdmName += (char) (65 + Math.random() * (90 - 65));
        }
        team.setTeamname(rdmName);
        return team;
    }
    
    /**
     * Simulates a certain number of Tournaments and logs
     * the results into a log file.
     * 
     * @param teams The participating teams
     * @param n The number of tournaments
     */
    private void simulateNTournaments(Team[] teams, int n)
    {
        Map<Team, Integer> winTracker = new HashMap<>();
        
        for(Team team : teams)
        {
            winTracker.put(team, 0);
        }

        for(int i = 0; i < n; i++)
        {
            if(_worker.isCancelled())
            {
                return;
            }
            
            Team winner = _tournamentService.simulateTournament(teams, n);
            winTracker.put(winner, winTracker.get(winner) + 1);
            _displayFrame.addWinner(winner);
        }

        String winString = "Total wins of " + n + " Simulations:\n";
        
        for(Map.Entry<Team, Integer> entry : winTracker.entrySet())
        {
            winString += entry.getKey().getTeamname() + ": " + entry.getValue() + " Wins \n";
        }
        
        _handler.writeMultiLog(winString);
    }
    
    /**
     * Processes the tournaments in the background with a SwingWorker,
     * while keeping the responsability of the Application stable.
     * 
     * @param numberOfTournaments The number of tournaments to be simulated
     */
    private void processInBackground(int numberOfTournaments)
    {
        _worker = new SwingWorker<Void, String>() {
            
            @Override
            protected Void doInBackground() throws Exception
            {        
                simulateNTournaments(_simulationWindow.getTeams(), numberOfTournaments);
                return null;
            }
        };
        

        _displayFrame = new DisplayWinnerDialog(_simulationWindow.getFrame(), numberOfTournaments);
        addDisplayDialogListeners();
        
        _worker.addPropertyChangeListener(new SwingWorkerCancelWaiter(_displayFrame.getDialog()));
        _worker.execute();
        _displayFrame.openWindow();
        
    }
    
    /**
     * Adds the Listeners to the Window.
     */
    private void addListeners()
    {
        for (JTeamPanel teamPanel : _simulationWindow.getTeamPanels())
        {
            teamPanel.getSave().addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {                    
                    // Update Panel Name
                    String teamName = teamPanel.getTeamNameField().getText();
                    int index = _simulationWindow.getMainPane().getSelectedIndex();
                    _simulationWindow.getMainPane().setTitleAt(index, teamName);
                    
                    // Recalculate Avg Elo
                    try
                    {
                        double avgElo = _simulationWindow.calculateAvgElo(teamPanel.getElos());
                        teamPanel.setAvgElo(avgElo);   
                    }
                    catch (NumberFormatException e1)
                    {
                        JOptionPane.showMessageDialog(_frame, "Please enter only numbers!", "Alert",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        }
        
        _simulationWindow.getSimulateButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                _handler.writeLog("\n\n" + HIGHLIGHTER + " Tournament " + HIGHLIGHTER + "\n", 1);
                Team[][] simulatedBrackets = _tournamentService.simulateBrackets(_simulationWindow.getTeams());
                updateBrackets(simulatedBrackets[0], simulatedBrackets[1]);
                Team[][] simulatedPlayoffs = _tournamentService.simulatePlayoffs(simulatedBrackets[0], simulatedBrackets[1]);
                updatePlayoffTree(simulatedPlayoffs[0], simulatedPlayoffs[1], simulatedPlayoffs[2],
                        simulatedPlayoffs[3][0], simulatedPlayoffs[4][0]);

            }
        });
        
        _simulationWindow.getMultiSimulateButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try 
                {
                    String input = JOptionPane.showInputDialog("How many Tournaments should be simulated?");
                    if (input == null || input.isBlank()) return;
                    int n = Integer.parseInt(input);
                    processInBackground(n);
                }
                catch (NumberFormatException e2)
                {
                    JOptionPane.showMessageDialog(_frame, "Please enter only numeric characters!",
                            "Error!", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getClearLogButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object[] options = {"Simulation Log", "Multi Log"};
                String question = "Which log do you want to clear?";
                String title = "Clear log file";
                int messageType = JOptionPane.QUESTION_MESSAGE;
                String answer = (String) JOptionPane.showInputDialog(_frame, question, title, messageType, null, options, 0);
                
                if(answer == options[0])
                {
                    _handler.clearLog(FileHandler.LOG_PATH);
                }
                else if(answer == options[1])
                {

                    _handler.clearLog(FileHandler.MULTI_PATH);
                }
                
                if(answer != null)
                {
                    JOptionPane.showMessageDialog(_frame, "Log Cleared!", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getShowLogButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object[] options = {"Simulation Log", "Multi Log"};
                String question = "Which log do you want to open?";
                String title = "Open log file";
                int messageType = JOptionPane.QUESTION_MESSAGE;
                String answer = (String) JOptionPane.showInputDialog(_frame, question, title, messageType, null, options, 0);
                
                try
                {
                    if(answer == options[0])
                    {
                        _handler.openLogFile(FileHandler.LOG_PATH);
                    }
                    else if(answer == options[1])
                    {
    
                        _handler.openLogFile(FileHandler.MULTI_PATH);
                    }
                }
                catch (IOException e1) 
                {
                    JOptionPane.showMessageDialog(_frame, "Something went wrong opening the log!", "Error", 
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getFrame().addWindowListener(new WindowAdapter()
        {
            // Writes all the Team Data into JSON File on Closing the Window
            // Note that Teamnames must not be equal
            @Override
            public void windowClosing(WindowEvent e)
            {
                if(_worker != null)
                {
                    _worker.cancel(true);
                }
                _handler.writeTeams(_simulationWindow.getTeams());
            }
            
            @Override
            public void windowOpened(WindowEvent e) 
            {
                Team[] teams;
                try
                {
                    teams = _handler.readTeams();
                    _simulationWindow.setUpTeams(teams);
                }
                catch (NoTeamsYetException e1)
                {
                    // DO Nothing
                }
            }
        });
    }
    
    /**
     * Adds the Listeners to the Dialog.
     */
    private void addDisplayDialogListeners()
    {
        _displayFrame.getCloseButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if(!_worker.isCancelled() && !_worker.isDone())
                    {
                    int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                                    "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if(answer == JOptionPane.NO_OPTION)
                    {
                        return;
                    }
                }
                _worker.cancel(true);
                _displayFrame.closeWindow();
            }
        });
        
        _displayFrame.getStopButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if(_worker.isCancelled() || _worker.isDone()) return;
                int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                        "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if(answer == JOptionPane.NO_OPTION)
                {
                    return;
                }
                _worker.cancel(true);
            }
        });
        
        _displayFrame.getDialog().addWindowListener(new WindowAdapter()
        {
            // Writes all the Team Data into JSON File on Closing the Window
            // Note that Teamnames must not be equal
            @Override
            public void windowClosing(WindowEvent e)
            {
                if(_worker == null || _worker.isCancelled() || _worker.isDone())
                {
                    _displayFrame.closeWindow();
                    return;
                }
                
                int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                        "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if(answer == JOptionPane.NO_OPTION)
                {
                    return;
                }
                _worker.cancel(true);
                _displayFrame.closeWindow();
            }
        });
    }

    /**
     * Updates the Bracket Tables.
     * 
     * @param simulatedLB The simulated Upper Bracket
     * @param simulatedUB The simulated Lower Bracket
     */
    private void updateBrackets(Team[] simulatedUB, Team[] simulatedLB)
    {
        _simulationWindow.updateBrackets(simulatedUB, simulatedLB);
        
    }
    
    /**
     * Updates the Playoff Tree acording to the participants.
     * 
     * @param quarterParticipants The Team participating in the quarterfinals
     * @param quarterTeams The Teams winning the quarterfinals
     * @param semisTeams The Teams winning the semifinals
     * @param thirdPlaceWinner The Team that won the third place match
     * @param finalTeam The Team winning the finals
     */
    private void updatePlayoffTree(Team[] quarterParticipants, Team[] quarterTeams, Team[] semisTeams, Team thirdPlaceWinner, Team finalTeam)
    {
        _simulationWindow.updatePlayoffTree(quarterParticipants, quarterTeams, semisTeams, thirdPlaceWinner, finalTeam);
    }
    
    
}
