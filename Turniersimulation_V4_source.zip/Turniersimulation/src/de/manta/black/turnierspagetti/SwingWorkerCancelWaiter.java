package de.manta.black.turnierspagetti;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

/**
 * PropertyChange listener for the SwingWorker
 * 
 * @version 16.04.2022
 * @author Jonas Müller
 */
public class SwingWorkerCancelWaiter implements PropertyChangeListener
{
    private JDialog _dialog;

    /**
     * Waits for a SwingWorker to cancel
     * 
     * @param dialog The dialog on the SwingWorker
     */
    public SwingWorkerCancelWaiter(JDialog dialog)
    {
        this._dialog = dialog;
    }

    /**
     * Method that is called if the SwingWorker encounters a property Change
     */
    public void propertyChange(PropertyChangeEvent event)
    {
        if ("state".equals(event.getPropertyName())
                && SwingWorker.StateValue.DONE == event.getNewValue()) 
        {
            JOptionPane.showMessageDialog(_dialog, "The Simulation has ended.", "Simulation end", JOptionPane.WARNING_MESSAGE);
        }
    }
}

