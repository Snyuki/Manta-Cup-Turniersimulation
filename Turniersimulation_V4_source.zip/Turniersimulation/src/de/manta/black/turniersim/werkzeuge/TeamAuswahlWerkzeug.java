package de.manta.black.turniersim.werkzeuge;

import java.awt.CardLayout;

import javax.swing.JPanel;

/**
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class TeamAuswahlWerkzeug
{
    
    /**
     * The UI.
     */
    private TeamAuswahlWerkzeugUI _teamAuswahlWekzeugUI;

    /**
     * Constructor.
     */
    public TeamAuswahlWerkzeug()
    {
        _teamAuswahlWekzeugUI = new TeamAuswahlWerkzeugUI();
    }

    /**
     * Returns the Team Panels.
     * 
     * @return The Team Panels
     */
    public JPanel[] getTeamLayout()
    {
        return _teamAuswahlWekzeugUI.getUIPanels();
    }
}
