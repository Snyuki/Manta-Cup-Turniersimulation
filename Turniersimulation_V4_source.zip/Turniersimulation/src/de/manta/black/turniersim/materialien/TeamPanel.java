package de.manta.black.turniersim.materialien;

import java.awt.Color;
import java.awt.LayoutManager;

import javax.swing.JPanel;
import javax.swing.JTextField;

import de.manta.black.turniersim.werkzeuge.TConstants;

/**
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class TeamPanel extends JPanel
{

    /**
     * Constructor
     */
    public TeamPanel()
    {

        _teamPanels = new JPanel[TConstants.TEAM_COUNT];
        
        initPanel();
    }

    private JPanel[] _teamPanels;
    private JTextField[] _playerNameFields;
    private JTextField[] _playerEloFields;
    
    private JTextField _teamNameTextField;

    /**
     * Creates the Player Name Text Fields.
     */
    private void initPanel()
    {
        this.add(createTeamNameTextField());
        for(int i = 0; i < 24; i++)
        {
            this.add(createPlayerTextField());
        }
        this.setBackground(Color.BLUE);
        
    }

    /**
     * Creates a Player Text field.
     * 
     * @return A Player Text Field
     */
    private JTextField createPlayerTextField()
    {
        JTextField jtf = new JTextField("Test2");
        jtf.setSize(200, 50);
        return jtf;
    }
    
    /**
     * Creates the Team Name Text Field.
     */
    private JTextField createTeamNameTextField()
    {
        JTextField jtf = new JTextField("Test");
        jtf.setSize(300, 100);
        _teamNameTextField = jtf;
        
        return jtf;
        
    }

}
