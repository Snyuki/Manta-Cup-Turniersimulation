package de.manta.black.turniersim.materialien;

/**
 * This Class represents a player for a team.
 * The player has a in-game-name and an elo.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class Spieler
{
    
    // Local Vars
    
    /**
     * The Ingame name of the player.
     */
    private String _playerName;
    
    /**
     * The elo of the player.
     */
    private int _elo;
    
    /**
     * The Position of the player.
     */
    private String _position;

    /**
     * Constructor.
     * Initializes a new player.
     * The elo has to be between silver 4 and master (8 - 24).
     * 
     * @param name The In-Game Name of the player
     * @param elo The elo of the player
     * @param position The position of the player
     * 
     * @require name != null
     * @require elo >= 8
     * @require elo <= 24
     * @require !position.isBlank()
     * 
     * @ensure getPlayerName() == name
     * @ensure getElo() == elo
     * @ensure getPosition() == position
     */
    public Spieler(String name, int elo, String position)
    {
        assert name != null : "(Spieler) Vorbedingung verletzt: name ist null";
        assert elo >= 8 : "(Spieler) Vorbedingung verletzt: elo >= 8";
        assert elo <= 24 : "(Spieler) Vorbedingung verletzt: elo <= 24";
        assert !position.isBlank() : "(Spieler) Vorbedingung verletzt: !position.isBlank()";
        
        _playerName = name;
        _elo = elo;
        _position = position;
    }

    /**
     * Returns the Ingame name of the player.
     * 
     * @return the playerName
     * 
     * @ensure result != null
     */
    public String getPlayerName()
    {
        return _playerName;
    }

    /**
     * Sets the Ingame name of the player.
     * 
     * @param playerName the playerName to set
     * 
     * @require playername != null
     * 
     * @ensure getPlayerName() == playername
     */
    public void setPlayerName(String playerName)
    {
        assert playerName != null : "(setPlayerName) Vorbedingung verletzt: playerName ist null";
        
        this._playerName = playerName;
    }

    /**
     * Returns the elo of the player.
     * 
     * @return the elo of the player
     * 
     * @ensure elo != null
     */
    public int getElo()
    {
        return _elo;
    }

    /**
     * Sets the elo of the player.
     * 
     * @param elo the elo to set
     * 
     * @require elo >= 8
     * @require elo <= 24
     * 
     * @ensure getElo() == elo
     */
    public void setElo(int elo)
    {
        assert elo >= 8 : "(Spieler) Vorbedingung verletzt: elo >= 8";
        assert elo <= 24 : "(Spieler) Vorbedingung verletzt: elo <= 24";
        
        this._elo = elo;
    }
    
    /**
     * Returns the position of the player.
     * 
     * @return the position of the player
     * 
     * @ensure position != null
     */
    public String getPosition()
    {
        return _position;
    }

    /**
     * Sets the position of the player.
     * 
     * @param position the position to set
     * 
     * @require !position.isBlank()
     * 
     * @ensure getPosition() == position
     */
    public void setPosition(String position)
    {
        assert !position.isBlank() : "(setPosition) Vorbedingung verletzt: !position.isBlank()";
        
        this._position = position;
    }
    
    @Override
    public String toString()
    {
        return _playerName + ": " + _elo;
    }

}
