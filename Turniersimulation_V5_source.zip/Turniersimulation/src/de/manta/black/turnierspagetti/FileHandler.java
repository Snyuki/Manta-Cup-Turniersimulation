package de.manta.black.turnierspagetti;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.manta.black.turniersim.materialien.Spieler;
import de.manta.black.turniersim.materialien.Team;

/**
 * @version 12.04.2022
 * @author Jonas Müller
 *
 */
public class FileHandler
{
    
    /**
     * The path to the team json file.
     */
    private static final String FILE_PATH = "res/json/teams2.json";
    
    /**
     * The path to the log text file.
     */
    public static final String LOG_PATH = "res/log/log.txt";
    
    /**
     * The path to the multi log text file.
     */
    public static final String MULTI_PATH = "res/log/multi-log.txt";
    
    private static final String LOG_SEPERATOR = "\n--------------------------"
            + "-----------------------------\n";

    private PrintWriter _pw;
    private ProcessBuilder _pb;
    
    /**
     * 
     */
    public FileHandler()
    {
    }
    
    /**
     * Sets up the file enviroment to work with the json dict.
     * 
     */
    public void setUpEnviroment()
    {
        try
        {
            String path = getProgramPath();
            // Remove Program file from path
            String folderPath = path.substring(1, path.lastIndexOf('/'));
            // Remove Bin aswell if run is in IDE
            if (folderPath.substring(folderPath.length() - 3).equals("bin"))
            {
                folderPath = folderPath.substring(0, folderPath.lastIndexOf('/'));
            }
            
            // Create Dir and file if not existent
            Files.createDirectories(Paths.get(folderPath + "/res/json/"));
            Files.createDirectories(Paths.get(folderPath + "/res/log/"));
            Files.createFile(Paths.get(folderPath + "/" + FILE_PATH));
            Files.createFile(Paths.get(folderPath + "/" + LOG_PATH));
            Files.createFile(Paths.get(folderPath + "/" + MULTI_PATH));
            
        }
        catch (FileAlreadyExistsException e) 
        {
            // Do Nothing
        }
        catch (IOException | URISyntaxException e)
        {
            e.printStackTrace();
        }
    }
    
    /**
     * Opens a log file in notepad.exe.
     * If the file is not found an exeption is thrown.
     * 
     * @param path The path to the log file
     * 
     * @throws IOException If the file is not found or anything else went wrong building the process
     */
    public void openLogFile(String path) throws IOException
    {
        _pb = new ProcessBuilder("notepad.exe", path);
        _pb.start();
    }
    
    /**
     * Writes the log for a multisimulation of tournaments.
     * 
     * @param log The Log that should be written
     */
    public void writeMultiLog(String log)
    {
        try
        {
            FileWriter fw = new FileWriter(new File(MULTI_PATH), true);
            _pw = new PrintWriter(fw);
            _pw.write(log);
            _pw.close();
        }
        catch (FileNotFoundException e)
        {
            JFrame jFrame = new JFrame();
            JOptionPane.showMessageDialog(jFrame, "MultiLog-File not Found! Try restarting "
                    + "the Program or manualy create the file: " + MULTI_PATH);
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println("Unsupported Encoding");
        }
        catch (IOException e)
        {
            System.out.println("IO Exception");
        }
    }
    
    /**
     * Writes the given String to the logfile.
     * 
     * @param log The Log that is to be written
     * @param mode 0 for seperator at the end of the line, 1 for no seperator
     */
    public void writeLog(String log, int mode)
    {
        try
        {
            FileWriter fw = new FileWriter(new File(LOG_PATH), true);
            _pw = new PrintWriter(fw);
            
            switch (mode)
            {
            case 0:
            {
                _pw.write(log + LOG_SEPERATOR);
                break;
            }
            case 1:
            {
                _pw.write(log);
                break;
            }
            default:
                _pw.write(log + LOG_SEPERATOR);
            }
            
            _pw.close();
        }
        catch (FileNotFoundException e)
        {
            JFrame jFrame = new JFrame();
            JOptionPane.showMessageDialog(jFrame, "Log-File not Found! Try restarting "
                    + "the Program or manualy create the file: " + LOG_PATH);
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println("Unsupported Encoding");
        }
        catch (IOException e)
        {
            System.out.println("IO Exception");
        }
    }
    
    /**
     * Clears the passed log file.
     * 
     * @param path The logfile-path that should be cleared
     */
    public void clearLog(String path)
    {
        try
        {
            _pw = new PrintWriter(path);
            _pw.write("");
            _pw.close();
        }
        catch (FileNotFoundException e)
        {
            JFrame jFrame = new JFrame();
            JOptionPane.showMessageDialog(jFrame, "Log-File not Found! Try restarting "
                    + "the Program or manualy create the file: " + LOG_PATH);
        }
    }
    
    /**
     * Returns the current Program Path as a String.
     * 
     * @return The program Path
     * 
     * @throws URISyntaxException If there was an Error in the URI Syntax
     */
    private String getProgramPath() throws URISyntaxException
    {
        return getClass().getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
    }

    /**
     * Reads all Teams from the json file.
     * 
     * @return An Array of all the Teams
     * 
     * @throws NoTeamsYetException If there are no teams saved yet
     */
    public Team[] readTeams() throws NoTeamsYetException
    {
        Team[] teams = new Team[12];

        try
        {
            String jsonString = new String((Files.readAllBytes(Paths.get(FILE_PATH))), "utf-8");

            JSONArray jsonTeams = new JSONArray(jsonString);
            
            for(int i = 0; i < jsonTeams.length(); i++)
            {
                String teamName = ((JSONObject) jsonTeams.get(i)).getString("Teamname");
                JSONObject jsonTeam = (JSONObject) jsonTeams.get(i);
                
                Spieler[] players = new Spieler[8];
                
                int k = 0;
                for(int j = 0; j < jsonTeam.length(); j++)
                {
                    String currentPosition = jsonTeam.names().getString(j);
                    // Drop non player case
                    if(currentPosition.equals("Teamname"))
                    {
                        continue;
                    }
                    
                    JSONObject playerObj = (JSONObject) jsonTeam.get(currentPosition);
                    String playerName = playerObj.getString("Summoner Name");
                    int playerElo = playerObj.getInt("Elo");
                    players[k] = new Spieler(playerName, playerElo, currentPosition);
                    k++;
                }

                teams[i] = new Team(players, teamName);
            }
        }
        catch (JSONException e)
        {
            // Do nothing cause Array not set up yet
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        
        return teams;
    }
    
    /**
     * Writes the Teams into the json file
     * 
     * @param teams An Array of all the Teams
     */
    public void writeTeams(Team[] teams)
    {
        try
        {
            _pw = new PrintWriter(FILE_PATH, "UTF-8");
            
            JSONArray teamsObject = new JSONArray();
            
            for(Team team : teams)
            {
                Spieler[] players = team.getPlayers();  // The Players of the Team
                JSONObject teamObject = new JSONObject();   // The Json Object with for the Team
                try
                {
                    // Add Elements til one is null
                    teamObject.put("Teamname", team.getTeamname());
                    teamObject.put("Top", playerToObject(players[0]));
                    teamObject.put("Jngl", playerToObject(players[1]));
                    teamObject.put("Mid", playerToObject(players[2]));
                    teamObject.put("Adc", playerToObject(players[3]));
                    teamObject.put("Supp", playerToObject(players[4]));
                    teamObject.put("Sub1", playerToObject(players[5]));
                    teamObject.put("Sub2", playerToObject(players[6]));
                    teamObject.put("Sub3", playerToObject(players[7]));
                }
                catch (NullPointerException e)
                {
                    // Do Nothing cause not every sub has to be filled
                }
                
                teamsObject.put(teamObject);
            }
            
            _pw.println(teamsObject.toString(4));
            _pw.close();
        }
        catch (FileNotFoundException e)
        {
            JFrame jFrame = new JFrame();
            JOptionPane.showMessageDialog(jFrame, "Team-File not Found! Try restarting "
                    + "the Program or manualy create the file: " + FILE_PATH);
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println("Unsupported Encoding");
        }
    }
    
    /**
     * Creates a JSONObject out of a Spieler Object.
     * 
     * @param spieler The Player who is to be parsed
     * 
     * @return The JSONObject of the player
     */
    private JSONObject playerToObject(Spieler spieler)
    {
        JSONObject playerObject = new JSONObject();
        playerObject.put("Summoner Name", spieler.getPlayerName());
        playerObject.put("Elo", spieler.getElo());
        return playerObject;
    }
}
