package de.manta.black.turnierspagetti;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import de.manta.black.turniersim.materialien.Team;

/**
 * The Service Class which handles all the logic regarding the Matches
 * in a tournament.
 * To simulate a tournament call simulateTournament(teams).
 * To simulate only the brackets call simulateBrackets(teams).
 * To simulate only the playoffs call simulatePlayoffs(firstBracket, secondBracket).
 * 
 * @version 19.04.2022
 * @author Jonas Müller
 *
 */
public class TournamentService
{
    
    /** A highlighter for the written form of the tournament */
    private static final String HIGHLIGHTER = "-------------------------";
    
    /** The FileHandler of the Program */
    private FileHandler _handler;
    
    /** The number of tournaments that should be simulated */
    private long _numberOfTournaments;

    /**
     * Constructor.
     * 
     * @param handler The FileHandler of the Program
     */
    public TournamentService(FileHandler handler)
    {
        this._handler = handler;
    }
    
    /**
     * Simulates the Tournament with the given Teams.
     * It logs the detailed information about each game only if the numberOfTournaments is
     * below 10.
     * It returns an array with all placements and the winning team.
     * The array with all placements has the following structure:
     * 0. - 3.: Quarter loosers
     * 4.: 4th Place
     * 5.: 3rd Place
     * 6.: 2nd Place
     * 7.: 1st Place
     * 
     * @param teams The teams of the tournament
     * @param numberOfTournaments The number of tournaments that should be simulated
     * 
     * @return An Array with {all placements, the winning team}
     */
    public Team[][] simulateTournament(Team[] teams, long numberOfTournaments)
    {
        this._numberOfTournaments = numberOfTournaments;
        if(_numberOfTournaments >= 10)
        {
            Team[][] simulatedBrackets = simulateBracketsNoLog(teams);
            Team[][] simulatedPlayoffs = simulatePlayoffsNoLog(simulatedBrackets[0], simulatedBrackets[1]);
            return new Team[][] {simulatedPlayoffs[0], simulatedPlayoffs[4]};
        }
        Team[][] simulatedBrackets = simulateBrackets(teams);
        Team[][] simulatedPlayoffs = simulatePlayoffs(simulatedBrackets[0], simulatedBrackets[1]);
        return new Team[][] {simulatedPlayoffs[0], simulatedPlayoffs[4]};
    }
    
    /*
     *         Winner, Second-Place, Third-Place, Fourth-Place, Quarters, Group-First, Second, 3rd, 4th, 5th, 6th
     * Team 1: 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0
     * 
     * Return {Team winner, HashMap placements}
     * -> Try not to calculate winner by placements due to performance
     */

    /**
     * Simulates the Brackets and returns a two dimentsional Team Array
     * which holds the first Bracket in the 0th position and the second
     * Bracket in the 1st position.
     * 
     * @param teams The Teams participating
     * 
     * @return A Two Dimensional Array of the simulated Brackets
     */
    public Team[][] simulateBrackets(Team[] teams)
    {
        Team[] upperBracket = Arrays.copyOfRange(teams, 0, (teams.length / 2));
        Team[] lowerBracket = Arrays.copyOfRange(teams, teams.length / 2, teams.length);
        
        Team[][] simulatedBrackets = new Team[teams.length / (teams.length / 2)][teams.length / 2];
        _handler.writeLog("\n\n" + HIGHLIGHTER + " Groupphase 1 " + HIGHLIGHTER + "\n", 1);
        simulatedBrackets[0] = simulateBracket(upperBracket, true); // Simulate upper Bracket
        _handler.writeLog("\n\n" + HIGHLIGHTER + " Groupphase 2 " + HIGHLIGHTER + "\n", 1);
        simulatedBrackets[1] = simulateBracket(lowerBracket, true); // Simulate lower Bracket
        
        return simulatedBrackets;
    }
    
    /**
     * Simulates the Brackets and returns a two dimentsional Team Array
     * which holds the first Bracket in the 0th position and the second
     * Bracket in the 1st position.
     * 
     * @param teams The Teams participating
     * 
     * @return A Two Dimensional Array of the simulated Brackets
     */
    public Team[][] simulateBracketsNoLog(Team[] teams)
    {
        Team[] upperBracket = Arrays.copyOfRange(teams, 0, (teams.length / 2));
        Team[] lowerBracket = Arrays.copyOfRange(teams, teams.length / 2, teams.length);
        
        Team[][] simulatedBrackets = new Team[teams.length / (teams.length / 2)][teams.length / 2];
        simulatedBrackets[0] = simulateBracket(upperBracket, false); // Simulate upper Bracket
        simulatedBrackets[1] = simulateBracket(lowerBracket, false); // Simulate lower Bracket
        
        return simulatedBrackets;
    }
    
    /**
     * Simulates the Bracket.
     * 
     * Team 1 vs Team 2, 3, 4, 5, 6
     * Team 2 vs Team 3, 4, 5, 6
     * Team 3 vs Team 4, 5, 6
     * Team 4 vs Team 5, 6
     * Team 5 vs Team 6
     * 
     * @param bracket The bracket that is to be simulated
     * @param writeLog True if there should be log, else false
     * 
     * @return The simulated bracket
     */
    private Team[] simulateBracket(Team[] bracket, boolean writeLog)
    {
        /*
         * 1. Jedes Team | Wins
         * 2. simulate matches and fill 1.
         * 3. Return new Bracket (Array) with new seetings 
         */
        
        // Create Map that is to be updated while simulating
        Map<Team, Integer> bSimulation = new HashMap<>();
        
        // Initialize the Map
        for(int i = 0; i < bracket.length; i++)
        {
            bSimulation.put(bracket[i], 0);
        }
        
        // Simulate Matches
        for(int i = 0; i < bracket.length - 1; i++)
        {
            for(int j = 1 + i; j < bracket.length; j++)
            {
                if(simulateMatch(bracket[i], bracket[j], 1))
                {
                    bSimulation.put(bracket[i], bSimulation.get(bracket[i]) + 1);
                }
                else
                {
                    bSimulation.put(bracket[j], bSimulation.get(bracket[j]) + 1);                    
                }
            }
        }
        
        Team[] simulatedBracket = new Team[bracket.length];
        Map<Team, Integer> bSimulationCopy = new HashMap<>(bSimulation);
        // Evaluate Bracket Simulation
        for(int i = 0; i < bracket.length; i++)
        {
            Map.Entry<Team, Integer> highestEntry = null;
            
            for(Map.Entry<Team, Integer> entry : bSimulationCopy.entrySet())
            {
                if(highestEntry == null)
                {
                    highestEntry = entry;
                    continue;
                }
                
                if(highestEntry.getValue() < entry.getValue())
                {
                    highestEntry = entry;
                }
            }
            bSimulationCopy.remove(highestEntry.getKey());
            // XXX Value represents the wins of the Team. --> Use Later
            simulatedBracket[i] = highestEntry.getKey();
        }

        // Add Here: if(tiebreaker) {
        
        // Tiebreaker check if 4th and 5th have same wins
        if(bSimulation.get(simulatedBracket[3]) == bSimulation.get(simulatedBracket[4]))
        {
            if(writeLog)
            {
                _handler.writeLog(HIGHLIGHTER + " Tiebreaker " + HIGHLIGHTER, 0);
            }
            // Swap places if second team won
            if(!simualteBo(3, simulatedBracket[3], simulatedBracket[4]))
            {
                Team looser = simulatedBracket[3];
                simulatedBracket[3] = simulatedBracket[4];
                simulatedBracket[4] = looser;
            }
        }
        
        // }
        
        return simulatedBracket;
    }

    /**
     * Simulates a match between two Teams.
     * 
     * Calculates the winner by making a stochastic prediction after
     * adjusting the probability to win for the teams based of a 
     * exponential function.
     * 
     * Note that if the average elo difference between the two teams
     * is too big, the lower elo team has always still a 0.5% chance
     * to win.
     * 
     * @param team The first competetor
     * @param team2 The second competetor
     * @param boNumber The Gamenumber of the Match
     * 
     * @return True if Team1 won, else false
     */
    private boolean simulateMatch(Team team, Team team2, int boNumber)
    {
        // The probability if both Teams have the same avg elo
        // The higher the higher the chances of win for team(1)
        double probability = 50;
        
        double team1Elo = team.calculateAvgElo();
        double team2Elo = team2.calculateAvgElo();
        
        // The elo difference between the teams. (team(1) + eloDiff = team2)
        // Its higher, the lower the elo of team(1) compared to the elo of team2
        double eloDiff = team1Elo - team2Elo;
        
        if(team1Elo < team2Elo)
        {
            probability += Math.pow(eloDiff * 1.5, 2);
        } 
        else if(team1Elo > team2Elo)
        {
            probability -= Math.pow(eloDiff * 1.5, 2);    
        }
        
        if(probability <= 0)
        {
            probability = 0.5;
        }
        else if (probability >= 100)
        {
            probability = 99.5;
        }
        
        boolean result = probability < Math.random() * 100;
        
        if(_numberOfTournaments >= 10)
        {
            return result;
        }
        
        String logString = "Game: " + boNumber + "\n";
        logString += "Participants: " + team.getTeamname() + " vs. " + 
                team2.getTeamname() + "\n";
        logString += team.getTeamname() + "'s Average Elo: " 
                + roundToDecimal(team1Elo, 3) + "\n";
        logString += team2.getTeamname() + "'s Average Elo: " 
                + roundToDecimal(team2Elo, 3) + "\n";
        logString += "Elo Difference: " 
                + roundToDecimal(Math.abs(eloDiff), 3) + "\n";
        logString += team.getTeamname() + " Winchance: "
                + roundToDecimal(100 - probability, 3) + "%\n";
        logString += team2.getTeamname() + " Winchance: "
                + roundToDecimal(probability, 3) + "%\n";
        if(result)
        {
            logString += "Winner: " + team.getTeamname();
        }
        else
        {
            logString += "Winner: " + team2.getTeamname();
        }
        
        _handler.writeLog(logString, 0);
        
        return result;
    }
    
    /**
     * Rounds a double to a defined number of digits.
     * 
     * @param d The Number that should be rounded
     * @param n The Number of Digits
     * 
     * @return The rounded double
     */
    private double roundToDecimal(double d, int n)
    {
        return Math.round(d * Math.pow(10, n)) / Math.pow(10, n);
    }
    
    /**
     * Simulates the Playoffs.
     * First there are the Quarterfinals played as a B03.
     * The Matching will be:
     * - Bracket 1: 1. Seet vs Bracket 2: 4th Seet
     * - Bracket 1: 2. Seet vs Bracket 2: 3th Seet
     * - Bracket 1: 3. Seet vs Bracket 2: 2th Seet
     * - Bracket 1: 4. Seet vs Bracket 2: 1th Seet
     * 
     * Secondly there are the Semifinals played as a B03.
     * Lastly there are the Finals played as a Bo5.
     * 
     * @param upperBracket The First Bracket
     * @param lowerBracket The Second Bracket
     * 
     * @return All Playoff-Placements and the participating teams in each round of the playoffs 
     */
    public Team[][] simulatePlayoffs(Team[] upperBracket, Team[] lowerBracket)
    {
        Team[] quarterParticipants = new Team[8];
        Team[] quarterWinners = new Team[4];
        Team[] semiWinners = new Team[2];
        Team[] semiLosers = new Team[2];
        Team thirdPlaceWinner = null;
        Team finalWinner = null;
        
        // Participants
        quarterParticipants[0] = upperBracket[0];
        quarterParticipants[1] = upperBracket[2];
        quarterParticipants[2] = upperBracket[3];
        quarterParticipants[3] = upperBracket[1];
        quarterParticipants[4] = lowerBracket[3];
        quarterParticipants[5] = lowerBracket[1];
        quarterParticipants[6] = lowerBracket[0];
        quarterParticipants[7] = lowerBracket[2];
        
        // 1st, 2nd, 3rd, 4th, Quarters
        // 1, 1, 1, 1, 4
        Team[] koPlacements = new Team[8];
        
        _handler.writeLog("\n" + HIGHLIGHTER + " Quarterfinals " + HIGHLIGHTER + "\n", 1);
        
        // Quarters
        if(simualteBo(3, quarterParticipants[0], quarterParticipants[4]))
        {
            quarterWinners[0] = quarterParticipants[0];
            koPlacements[7] = quarterParticipants[4];
        }
        else
        {
            quarterWinners[0] = quarterParticipants[4];
            koPlacements[7] = quarterParticipants[0];
        }
        
        if(simualteBo(3, quarterParticipants[1], quarterParticipants[5]))
        {
            quarterWinners[1] = quarterParticipants[1];
            koPlacements[6] = quarterParticipants[5];
        }
        else
        {
            quarterWinners[1] = quarterParticipants[5];
            koPlacements[6] = quarterParticipants[1];
        }
        
        if(simualteBo(3, quarterParticipants[2], quarterParticipants[6]))
        {
            quarterWinners[2] = quarterParticipants[2];
            koPlacements[5] = quarterParticipants[6];
        }
        else
        {
            quarterWinners[2] = quarterParticipants[6];
            koPlacements[5] = quarterParticipants[2];
        }
        
        if(simualteBo(3, quarterParticipants[3], quarterParticipants[7]))
        {
            quarterWinners[3] = quarterParticipants[3];
            koPlacements[4] = quarterParticipants[7];
        }
        else
        {
            quarterWinners[3] = quarterParticipants[7];
            koPlacements[4] = quarterParticipants[3];
        }
        
        _handler.writeLog("\n" + HIGHLIGHTER + " Semifinals " + HIGHLIGHTER + "\n", 1);
        
        int j;
        // Semis
        for(int i = 0; i < 2; i++)
        {
            j = i * 2;
            if(simualteBo(3, quarterWinners[j], quarterWinners[j + 1]))
            {
                semiWinners[i] = quarterWinners[j];
                semiLosers[i] = quarterWinners[j + 1];
            }
            else
            {
                semiWinners[i] = quarterWinners[j + 1];
                semiLosers[i] = quarterWinners[j];
            }
        }

        // Game for 3rd Place
        _handler.writeLog("\n" + HIGHLIGHTER + " Third Place Finals " + HIGHLIGHTER + "\n", 1);
        if(simualteBo(5, semiLosers[0], semiLosers[1]))
        {
            thirdPlaceWinner = semiLosers[0];
            koPlacements[3] = semiLosers[1];
            koPlacements[2] = thirdPlaceWinner;
        }
        else
        {
            thirdPlaceWinner = semiLosers[1];
            koPlacements[3] = semiLosers[0];
            koPlacements[2] = thirdPlaceWinner;
        }
        
        // Finals
        _handler.writeLog("\n" + HIGHLIGHTER + " Finals " + HIGHLIGHTER + "\n", 1);
        
        if(simualteBo(5, semiWinners[0], semiWinners[1]))
        {
            finalWinner = semiWinners[0];
            koPlacements[1] = semiWinners[1];
            koPlacements[0] = finalWinner;
        }
        else
        {
            finalWinner = semiWinners[1];
            koPlacements[1] = semiWinners[0];
            koPlacements[0] = finalWinner;
        }
        return new Team[][] {koPlacements, quarterParticipants, quarterWinners, semiWinners, {thirdPlaceWinner}, {finalWinner}};
    }
    
    /**
     * Simulates the Playoffs.
     * First there are the Quarterfinals played as a B03.<br>
     * The Matching will be:<br>
     * - Bracket 1: 1. Seet vs Bracket 2: 4th Seet <br>
     * - Bracket 1: 2. Seet vs Bracket 2: 3th Seet <br>
     * - Bracket 1: 3. Seet vs Bracket 2: 2th Seet <br>
     * - Bracket 1: 4. Seet vs Bracket 2: 1th Seet <br>
     * <br>
     * Secondly there are the Semifinals played as a B03.<br>
     * Lastly there are the Finals played as a Bo5.
     * 
     * @param upperBracket The First Bracket
     * @param lowerBracket The Second Bracket
     * 
     * @return All Playoff-Placements and the participating teams in each round of the playoffs 
     */
    public Team[][] simulatePlayoffsNoLog(Team[] upperBracket, Team[] lowerBracket)
    {
        Team[] quarterParticipants = new Team[8];
        Team[] quarterWinners = new Team[4];
        Team[] semiWinners = new Team[2];
        Team[] semiLosers = new Team[2];
        Team thirdPlaceWinner = null;
        Team finalWinner = null;
        
        // Participants
        quarterParticipants[0] = upperBracket[0];
        quarterParticipants[1] = upperBracket[2];
        quarterParticipants[2] = upperBracket[3];
        quarterParticipants[3] = upperBracket[1];
        quarterParticipants[4] = lowerBracket[3];
        quarterParticipants[5] = lowerBracket[1];
        quarterParticipants[6] = lowerBracket[0];
        quarterParticipants[7] = lowerBracket[2];
        

        // 1st, 2nd, 3rd, 4th, Quarters
        // 1, 1, 1, 1, 4
        Team[] koPlacements = new Team[8];
        
        // Quarters
        if(simualteBo(3, quarterParticipants[0], quarterParticipants[4]))
        {
            quarterWinners[0] = quarterParticipants[0];
            koPlacements[7] = quarterParticipants[4];
        }
        else
        {
            quarterWinners[0] = quarterParticipants[4];
            koPlacements[7] = quarterParticipants[0];
        }
        
        if(simualteBo(3, quarterParticipants[1], quarterParticipants[5]))
        {
            quarterWinners[1] = quarterParticipants[1];
            koPlacements[6] = quarterParticipants[5];
        }
        else
        {
            quarterWinners[1] = quarterParticipants[5];
            koPlacements[6] = quarterParticipants[1];
        }
        
        if(simualteBo(3, quarterParticipants[2], quarterParticipants[6]))
        {
            quarterWinners[2] = quarterParticipants[2];
            koPlacements[5] = quarterParticipants[6];
        }
        else
        {
            quarterWinners[2] = quarterParticipants[6];
            koPlacements[5] = quarterParticipants[2];
        }
        
        if(simualteBo(3, quarterParticipants[3], quarterParticipants[7]))
        {
            quarterWinners[3] = quarterParticipants[3];
            koPlacements[4] = quarterParticipants[7];
        }
        else
        {
            quarterWinners[3] = quarterParticipants[7];
            koPlacements[4] = quarterParticipants[3];
        }
        
        int j;
        // Semis
        for(int i = 0; i < 2; i++)
        {
            j = i * 2;
            if(simualteBo(3, quarterWinners[j], quarterWinners[j + 1]))
            {
                semiWinners[i] = quarterWinners[j];
                semiLosers[i] = quarterWinners[j + 1];
            }
            else
            {
                semiWinners[i] = quarterWinners[j + 1];
                semiLosers[i] = quarterWinners[j];
            }
        }

        // Game for 3rd Place
        if(simualteBo(5, semiLosers[0], semiLosers[1]))
        {
            thirdPlaceWinner = semiLosers[0];
            koPlacements[3] = semiLosers[1];
            koPlacements[2] = thirdPlaceWinner;
        }
        else
        {
            thirdPlaceWinner = semiLosers[1];
            koPlacements[3] = semiLosers[0];
            koPlacements[2] = thirdPlaceWinner;
        }
        
        // Finals
        if(simualteBo(5, semiWinners[0], semiWinners[1]))
        {
            finalWinner = semiWinners[0];
            koPlacements[1] = semiWinners[1];
            koPlacements[0] = finalWinner;
        }
        else
        {
            finalWinner = semiWinners[1];
            koPlacements[1] = semiWinners[0];
            koPlacements[0] = finalWinner;
        }
        return new Team[][] {koPlacements, quarterParticipants, quarterWinners, semiWinners, {thirdPlaceWinner}, {finalWinner}};
    }

    
    /**
     * Simulates a BoX between two Teams.
     * 
     * @param boCount The Number of Games that will be played
     * @param team1 The first Team
     * @param team2 The second Team
     * 
     * @return True if Team 1 won, else false
     * 
     * @require boCount % 2 != 0
     */
    private boolean simualteBo(int boCount, Team team1, Team team2)
    {
        assert boCount % 2 != 0 : "(simualteBo) Vorbedingung verletzt: boCount % 2 != 0";
        
        int t1Win = 0;
        int t2Win = 0;
        
        int i = 0;
        
        while((i < boCount) && (t1Win < (boCount + 1) / 2) && (t2Win < (boCount + 1) / 2))
        {
            if(simulateMatch(team1, team2, i + 1))
            {
                t1Win++;
            }
            else
            {
                t2Win++;
            }
            i++;
        }
        
        return t1Win > t2Win;
    }
}
