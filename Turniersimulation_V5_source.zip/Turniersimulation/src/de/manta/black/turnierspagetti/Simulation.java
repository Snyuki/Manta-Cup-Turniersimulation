package de.manta.black.turnierspagetti;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

import de.manta.black.turniersim.materialien.Team;

/**
 * @version 05.04.2022
 * @author Jonas Müller
 *
 */
public class Simulation
{   
    
    private static final String HIGHLIGHTER = "-------------------------";

    /**
     * The total number of tournaments that should be shown in the table
     * while multi-simulating.
     * 
     * Cant be a long since the scollToEnd() function wouldnt work anymore.
     */
    static final int MAX_TOURNAMENTS_AT_ONCE = 5000000;

    /** The Tournament Service handling everything in a tournament */
    private TournamentService _tournamentService;
    
    // The Simulation GUI
    private Window _simulationWindow;
    private FileHandler _handler;
    private JFrame _frame;
    private DisplayWinnerDialog _displayFrame;

    private SwingWorker<Void, String> _worker;
    
    /**
     * Simulates the Tournament
     */
    public Simulation()
    {
        _simulationWindow = new Window();
        _handler = new FileHandler();
        _frame = new JFrame();
        
        _handler.setUpEnviroment();
        addListeners();
        _tournamentService = new TournamentService(_handler);
        _simulationWindow.showFrame();
    }

    /*
     * TODO Current Tasks
     * XXX Create option to enable gui when simulating to save gpu -> update progress bar?
     * XXX Make Tiebreaker optional for performance
     * XXX Add Combobox for elo
     *      -> Tab übergreifende Checkbox zum umschalten zwischen Zahl und Combobox
     * XXX Multisimulate -> Wie oft hat jedes Team gegen ein anderes Team gewonnen / verloren
     * XXX Multisimulate -> Durchschnittliche Platzierung in der eigenen Gruppe
     * XXX Runtime des Programms zeigen
     * XXX MVP für Turnier vergeben
     *      -> Die besten 4 Teams haben jeweils eine absteigende Wahrscheinlichkeit den MVP zu erhalten
     *      -> Innerhalb des Teams gibt es eine sich nach der Spielerelo richtende Wahrscheinlichkeit den MVP zu erhalten
     * XXX Avg Elo/Tabname update bei Programmstart
     * XXX Icons hochladen die neben dem Team angezeigt werden
     * XXX Add Wins of the Team to the Table representation
     * EXTRA Cancel und Resume Multisimulate (do with return numberOfDoneSims -> Add up to what it should simulate)
     */
    
    /*
     * MC3 Make the Max tournaments at once variable changeable for the user
     * MC3 Möglichkeit die Turnierart zu ändern
     * MC3 Teamanzahl als Konstante festhalten um Skalierbarkeit zu erreichen
     */
    
    /**
     * Simulates a certain number of Tournaments and logs
     * the results into a log file.
     * 
     * @param teams The participating teams
     * @param n The total number of tournaments
     * @param nMax The number of tournaments that should be shown in the window
     */
    private void simulateNTournaments(Team[] teams, long n, long nMax)
    {
        Map<Team, int[]> winTracker = new HashMap<>();
        
        for(Team team : teams)
        {
            winTracker.put(team, new int[8]);
        }

        try
        {
            for(int i = 0; i < n; i++)
            {
                if(_worker.isCancelled())
                {
                    n = i;
                    break;
                }
                
                if(i % nMax == 0 && (n - 1) != i)
                {
                    _displayFrame.removeAllRows();
                }
                
                Team[][] simulatedTournament = _tournamentService.simulateTournament(teams, n);
                Team winner = simulatedTournament[1][0];
                for(int j = 0; j < simulatedTournament[0].length; j++)
                {
                    // j = 0 -> Winner++; j = 1 -> 2nd Place++; ...
                    winTracker.get(simulatedTournament[0][j])[j]++;
                }
                _displayFrame.addWinner(winner);
            }
        }
        catch (ArrayIndexOutOfBoundsException e)
        {
            // Do nothing
        }

        String winString = "Total Placements of " + n + " Simulations: (Wins, 2nd, 3rd, 4th, Quarter participations)\n";
        
        for(Map.Entry<Team, int[]> entry : winTracker.entrySet())
        {
            int[] placings = entry.getValue();
            winString += entry.getKey().getTeamname() + ": " + placings[0] + " Wins, " + placings[1] + ", " + placings[2] 
                    + ", " + placings[3] + ", " + (placings[4] + placings[5] + placings[6] + placings[7]) + "\n";
        }
        
        _handler.writeMultiLog(winString);
    }
    
    /**
     * Processes the tournaments in the background with a SwingWorker,
     * while keeping the responsability of the Application stable.
     * 
     * @param numberOfTournaments The number of tournaments to be simulated
     */
    private void processInBackground(long numberOfTournaments)
    {
        _worker = new SwingWorker<Void, String>() {
            
            @Override
            protected Void doInBackground() throws Exception
            {   
                simulateNTournaments(_simulationWindow.getTeams(), numberOfTournaments, MAX_TOURNAMENTS_AT_ONCE);
                return null;
            }
        };
        

        _displayFrame = new DisplayWinnerDialog(_simulationWindow.getFrame(), numberOfTournaments);
        addDisplayDialogListeners();
        
        _worker.addPropertyChangeListener(new SwingWorkerCancelWaiter(_displayFrame.getDialog()));
        _worker.execute();
        _displayFrame.openWindow();
        
    }
    
    /**
     * Adds the Listeners to the Window.
     */
    private void addListeners()
    {
        for (JTeamPanel teamPanel : _simulationWindow.getTeamPanels())
        {
            teamPanel.getSave().addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {                    
                    // Update Panel Name
                    String teamName = teamPanel.getTeamNameField().getText();
                    int index = _simulationWindow.getMainPane().getSelectedIndex();
                    _simulationWindow.getMainPane().setTitleAt(index, teamName);
                    
                    // Recalculate Avg Elo
                    try
                    {
                        double avgElo = _simulationWindow.calculateAvgElo(teamPanel.getElos());
                        teamPanel.setAvgElo(avgElo);   
                    }
                    catch (NumberFormatException e1)
                    {
                        JOptionPane.showMessageDialog(_frame, "Please enter only numbers!", "Alert",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        }
        
        _simulationWindow.getSimulateButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                _handler.writeLog("\n\n" + HIGHLIGHTER + " Tournament " + HIGHLIGHTER + "\n", 1);
                Team[][] simulatedBrackets = _tournamentService.simulateBrackets(_simulationWindow.getTeams());
                updateBrackets(simulatedBrackets[0], simulatedBrackets[1]);
                Team[][] simulatedPlayoffs = _tournamentService.simulatePlayoffs(simulatedBrackets[0], simulatedBrackets[1]);
                updatePlayoffTree(simulatedPlayoffs[1], simulatedPlayoffs[2], simulatedPlayoffs[3],
                        simulatedPlayoffs[4][0], simulatedPlayoffs[5][0]);

            }
        });
        
        _simulationWindow.getMultiSimulateButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try 
                {
                    String input = JOptionPane.showInputDialog("How many Tournaments should be simulated?");
                    if (input == null || input.isBlank()) return;
                    long n = Long.parseLong(input);
                    processInBackground(n);
                }
                catch (NumberFormatException e2)
                {
                    JOptionPane.showMessageDialog(_frame, "Please enter only numeric characters!",
                            "Error!", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getClearLogButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object[] options = {"Simulation Log", "Multi Log"};
                String question = "Which log do you want to clear?";
                String title = "Clear log file";
                int messageType = JOptionPane.QUESTION_MESSAGE;
                String answer = (String) JOptionPane.showInputDialog(_frame, question, title, messageType, null, options, 0);
                
                if(answer == options[0])
                {
                    _handler.clearLog(FileHandler.LOG_PATH);
                }
                else if(answer == options[1])
                {

                    _handler.clearLog(FileHandler.MULTI_PATH);
                }
                
                if(answer != null)
                {
                    JOptionPane.showMessageDialog(_frame, "Log Cleared!", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getShowLogButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object[] options = {"Simulation Log", "Multi Log"};
                String question = "Which log do you want to open?";
                String title = "Open log file";
                int messageType = JOptionPane.QUESTION_MESSAGE;
                String answer = (String) JOptionPane.showInputDialog(_frame, question, title, messageType, null, options, 0);
                
                try
                {
                    if(answer == options[0])
                    {
                        _handler.openLogFile(FileHandler.LOG_PATH);
                    }
                    else if(answer == options[1])
                    {
    
                        _handler.openLogFile(FileHandler.MULTI_PATH);
                    }
                }
                catch (IOException e1) 
                {
                    JOptionPane.showMessageDialog(_frame, "Something went wrong opening the log!", "Error", 
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getFrame().addWindowListener(new WindowAdapter()
        {
            // Writes all the Team Data into JSON File on Closing the Window
            // Note that Teamnames must not be equal
            @Override
            public void windowClosing(WindowEvent e)
            {
                if(_worker != null)
                {
                    _worker.cancel(true);
                }
                _handler.writeTeams(_simulationWindow.getTeams());
            }
            
            @Override
            public void windowOpened(WindowEvent e) 
            {
                Team[] teams;
                try
                {
                    teams = _handler.readTeams();
                    _simulationWindow.setUpTeams(teams);
                }
                catch (NoTeamsYetException e1)
                {
                    // DO Nothing
                }
            }
        });
    }
    
    /**
     * Adds the Listeners to the Dialog.
     */
    private void addDisplayDialogListeners()
    {
        _displayFrame.getCloseButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if(!_worker.isCancelled() && !_worker.isDone())
                    {
                    int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                                    "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if(answer == JOptionPane.NO_OPTION)
                    {
                        return;
                    }
                }
                _worker.cancel(true);
                _displayFrame.closeWindow();
            }
        });
        
        _displayFrame.getStopButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if(_worker.isCancelled() || _worker.isDone()) return;
                int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                        "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if(answer == JOptionPane.NO_OPTION)
                {
                    return;
                }
                _worker.cancel(true);
            }
        });
        
        _displayFrame.getDialog().addWindowListener(new WindowAdapter()
        {
            // Writes all the Team Data into JSON File on Closing the Window
            // Note that Teamnames must not be equal
            @Override
            public void windowClosing(WindowEvent e)
            {
                if(_worker == null || _worker.isCancelled() || _worker.isDone())
                {
                    _displayFrame.closeWindow();
                    return;
                }
                
                int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                        "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if(answer == JOptionPane.NO_OPTION)
                {
                    return;
                }
                _worker.cancel(true);
                _displayFrame.closeWindow();
            }
        });
    }

    /**
     * Updates the Bracket Tables.
     * 
     * @param simulatedLB The simulated Upper Bracket
     * @param simulatedUB The simulated Lower Bracket
     */
    private void updateBrackets(Team[] simulatedUB, Team[] simulatedLB)
    {
        _simulationWindow.updateBrackets(simulatedUB, simulatedLB);
        
    }
    
    /**
     * Updates the Playoff Tree acording to the participants.
     * 
     * @param quarterParticipants The Team participating in the quarterfinals
     * @param quarterTeams The Teams winning the quarterfinals
     * @param semisTeams The Teams winning the semifinals
     * @param thirdPlaceWinner The Team that won the third place match
     * @param finalTeam The Team winning the finals
     */
    private void updatePlayoffTree(Team[] quarterParticipants, Team[] quarterTeams, Team[] semisTeams, Team thirdPlaceWinner, Team finalTeam)
    {
        _simulationWindow.updatePlayoffTree(quarterParticipants, quarterTeams, semisTeams, thirdPlaceWinner, finalTeam);
    }
    
    
}
