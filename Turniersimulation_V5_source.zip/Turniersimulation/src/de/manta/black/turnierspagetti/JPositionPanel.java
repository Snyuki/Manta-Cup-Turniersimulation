package de.manta.black.turnierspagetti;

import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * A Panel that combines a Label with the given Position,
 * a TextField for the Name and one for the Elo in a FlowLayout.
 * 
 * @version 07.04.2022
 * @author Jonas Müller
 *
 */
public class JPositionPanel extends JPanel
{
    
    /**
     * Generated ID
     */
    private static final long serialVersionUID = -2842134547248295511L;

    private static String POSITION;

    private JLabel _positionLabel;
    private JTextField _nameField;
    private JTextField _eloField;
    
    /**
     * Constructor
     * 
     * @param position The Position of the Player
     */
    public JPositionPanel(String position)
    {
        POSITION = position;
        initPanel();
        initComponents();
    }

    /**
     * Initializes the Components
     */
    private void initComponents()
    {
        _positionLabel = new JLabel(POSITION + ":");
        add(_positionLabel);
        _nameField = new JTextField();
        _nameField.setColumns(20);
        add(_nameField);
        _eloField = new JTextField();
        _eloField.setColumns(5);
        add(_eloField);
    }

    /**
     * Initialize the Panel
     */
    private void initPanel()
    {
        setLayout(new FlowLayout());
    }

    /**
     * @return the nameField
     */
    public JTextField getNameField()
    {
        return _nameField;
    }

    /**
     * @return the eloField
     */
    public JTextField getEloField()
    {
        return _eloField;
    }

    /**
     * @param nameField the nameField to set
     */
    public void setNameField(JTextField nameField)
    {
        this._nameField = nameField;
    }

    /**
     * @param eloField the eloField to set
     */
    public void setEloField(JTextField eloField)
    {
        this._eloField = eloField;
    }
    
    
        
}
