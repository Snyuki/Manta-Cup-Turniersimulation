package de.manta.black.turnierspagetti;

import java.awt.BorderLayout;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import de.manta.black.turniersim.materialien.Team;

/**
 * This Class displayes the current winner of a simulated Torunament
 * in a constantly updating Dialog.
 * 
 * @version 15.04.2022
 * @author Jonas Müller
 */
public class DisplayWinnerDialog extends JDialog
{
    
    /**
     * Serial Id
     */
    private static final long serialVersionUID = 1L;

    private static final String[] COLUMN_NAMES = new String[] {"Iteration", "Winner"};
    
    private long _currentIteration;
    
    private JTable _winnersTable;
    private DefaultTableModel _tableModel;
    private JScrollPane _scrollPane;

    private JButton _stopDialogButton;
    private JButton _closeDialogButton;
    
    /**
     * Constructor.
     * 
     * @param parentFrame The Parent Frame of the Dialog
     * @param iterations The total number of simulations
     */
    public DisplayWinnerDialog(JFrame parentFrame, long iterations)
    {
        super(parentFrame, "Simulating " + iterations + " Tournaments", true);
        _currentIteration = 0;
        
        setUpFrame();
    }
    
    /**
     * Sets up the Frame for the display of the winners.
     */
    private void setUpFrame()
    {
        this.setBounds(300, 300, 300, 200);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());

        _tableModel = new DefaultTableModel();
        _tableModel.setColumnIdentifiers(COLUMN_NAMES);
        _winnersTable = new JTable(_tableModel);
        _winnersTable.setEnabled(false);
        
        _scrollPane = new JScrollPane(_winnersTable);
        tablePanel.add(_scrollPane, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel();
        _stopDialogButton = new JButton("Stop");
        buttonPanel.add(_stopDialogButton);
        _closeDialogButton = new JButton("Close");
        buttonPanel.add(_closeDialogButton);
        tablePanel.add(buttonPanel, BorderLayout.SOUTH);
        
        this.getContentPane().add(tablePanel);
    }
    
    /**
     * Adds a winner to the representation and updates the table.
     * Deletes the first entry (FIFO) if the entry length is higher than
     * a certain value.
     * 
     * @param winner The winner of the tournament
     */
    public void addWinner(Team winner)
    {
        _tableModel.addRow(new Object[] {(_currentIteration + 1) + ".", winner.getTeamname()});
        _currentIteration++;
        scrollToEnd();
    }

    /**
     * Scrolls to the end of the scoll pane
     */
    private void scrollToEnd()
    {
        int lastRow = _winnersTable.getModel().getRowCount() - 1;
        Rectangle r = _winnersTable.getCellRect(lastRow, 0, true);
        _winnersTable.scrollRectToVisible(r);
    }
    
    /**
     * Removes all rows from the table model.
     */
    public void removeAllRows()
    {
        _tableModel.setRowCount(0);
    }
    
    /**
     * Returns the Close Dialog Button
     * 
     * @return The close Button
     */
    public JButton getCloseButton()
    {
        return _closeDialogButton;
    }
    
    /**
     * Returns the Stop Dialog Button
     * 
     * @return The Stop Button
     */
    public JButton getStopButton()
    {
        return _stopDialogButton;
    }
    
    /**
     * Returns the Dialog.
     * 
     * @return The dialog
     */
    public JDialog getDialog()
    {
        return this;
    }
    
    /**
     * Opens the Window
     */
    public void openWindow()
    {
        this.repaint();
        this.setVisible(true);
    }
    
    /**
     * Closes the Window
     */
    public void closeWindow()
    {
        this.dispose();
    }
}
