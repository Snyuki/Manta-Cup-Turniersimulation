package de.manta.black.turniersim.werkzeuge;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import de.manta.black.turniersim.materialien.TeamPanel;


/**
 * Main Window.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class SimWerkzeugUI
{

    private static final String NAME = "Turniersimulation Manta Cup";
    
    private JFrame _frame;
    
    private JPanel _menuPanel;
    private JPanel _teamViewPanel;
    
    private JPanel[] _teamPanels;
    
    private CardLayout _cLayout;
    
    private JButton[] _menuButtons;
    
    /**
     * Constructor.
     * 
     * @param teamPanels The Team Panels
     */
    public SimWerkzeugUI(JPanel[] teamPanels)
    {
        _teamPanels = teamPanels;
        
        initGUI();
    }
    
    /**
     * Initializes GUI and sets the layout.
     * Listeners are added.
     */
    private void initGUI()
    {
        _frame = new JFrame(NAME);
        _frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        _frame.getContentPane()
            .setBackground(UIConstants.BACKGROUND_COLOR);
        createMenuPanel();
        createTeamViewPanel();
        _frame.setTitle(NAME);
        _frame.pack();
        _frame.setSize(1100, 768);
    }

    /**
     * Sets a team Panel.
     * 
     * @param team The Teamnumber of the selected team
     */
    private void setTeamPanel(int team)
    {
                
    }

    /**
     * Erzeugt das Menü mit Ausleih- und Rückgabe-Button und Titel.
     */
    private void createMenuPanel()
    {
        _menuPanel = new JPanel();
        FlowLayout auswahlPanelLayout = new FlowLayout();
        auswahlPanelLayout.setAlignment(FlowLayout.LEFT);
        _menuPanel.setLayout(auswahlPanelLayout);
        _frame.getContentPane()
            .add(_menuPanel, BorderLayout.NORTH);
        _menuPanel.setBackground(UIConstants.BACKGROUND_COLOR);
        createMenuButtons();
    }

    /**
     * Creates the Buttons for the Menu.
     */
    private void createMenuButtons()
    {
        _menuButtons = new JButton[12];
        for(int i = 0; i < 12; i++)
        {
            JButton b = new JButton("Team " + i);
            _menuButtons[i] = b;
            _menuPanel.add(b);
        }
    }
    
    /**
     * Creates the Team View Panel.
     */
    private void createTeamViewPanel()
    {
        _teamViewPanel = new JPanel();
//        _cLayout = new CardLayout();
//        
//        // Create Layout
//        for(int i = 0; i < TConstants.TEAM_COUNT; i++)
//        {
//            _cLayout.addLayoutComponent(new TeamPanel(), TConstants.TEAMS[i]);
//            System.out.println();
//        }
//        
//        _teamViewPanel.setLayout(_cLayout);
//        _cLayout.show(_teamViewPanel, TConstants.TEAMS[0]);
         _frame.getContentPane().add(new TeamPanel(), BorderLayout.CENTER);
//        _frame.getContentPane().add(_teamViewPanel, BorderLayout.CENTER);
        System.out.println(_teamViewPanel.getComponentCount());
        for(Component c : _teamViewPanel.getComponents()) {
            System.out.println("1: " + c);
        }
        refreshLayout();
    }

    /**
     * Aktualisiert das Layout.
     */
    private void refreshLayout()
    {
        _frame.validate();
    }
    
    /**
     * Shows the Main Window.
     */
    public void showWindow()
    {
        _frame.setLocationRelativeTo(null);
        _frame.setVisible(true);
    }
}
