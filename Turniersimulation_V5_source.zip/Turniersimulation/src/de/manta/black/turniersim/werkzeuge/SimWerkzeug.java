package de.manta.black.turniersim.werkzeuge;

/**
 * Main Werkzeug.
 * Contains all other Werkzeuge.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class SimWerkzeug
{

    /**
     * The UI.
     */
    private SimWerkzeugUI _simWerkzeugUI;
    
    /**
     * The {@link TeamAuswahlWerkzeug}
     */
    private final TeamAuswahlWerkzeug _teamAuswahlWerkzeug;
    
    /**
     * Constructor.
     * 
     */
    public SimWerkzeug()
    {
        _teamAuswahlWerkzeug = new TeamAuswahlWerkzeug();
        _simWerkzeugUI = new SimWerkzeugUI(_teamAuswahlWerkzeug.getTeamLayout());
    }

    /**
     * Shows the Main Window.
     */
    public void showWindow()
    {
        _simWerkzeugUI.showWindow();
    }
}
