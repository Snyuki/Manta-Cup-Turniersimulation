package de.manta.black.turniersim.werkzeuge;

/**
 * This Class holds constants for the Simulation.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class TConstants
{
    public static final String[] TEAMS = new String[] {"Team One", "Team Two", "Team Three", "Team Four", "Team Five",
            "Team Six", "Team Seven", "Team Eight", "Team Nine", "Team Ten", "Team Eleven", "Team Twelve"};

    public static final int TEAM_COUNT = 12;
    
    /**
     * 
     */
    public TConstants()
    {
        // TODO Auto-generated constructor stub
    }

    
}
