package de.manta.black.turniersim.materialien;

/**
 * This Class represents a Team.
 * A Team consists of 5-8 players and has a Teamname.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class Team
{

    /**
     * A list of all players on the team.
     */
    private Spieler[] _players;
    
    /**
     * The Teamname of the team
     */
    private String _teamname;
    
    /**
     * Constructor.
     * The passed list of the players has to have a length of 8.
     * 
     * 
     * @param players A list of all players on the Team
     * @param teamname The Teamname
     * 
     * @require players != null
     * @require players.length == 8
     * @require players[0] != null
     * @require players[1] != null
     * @require players[2] != null
     * @require players[3] != null
     * @require players[4] != null
     * @require teamname != null
     * 
     * @ensure getPlayers() == players
     * @ensure getTeamname() == teamname
     * 
     */
    public Team(Spieler[] players, String teamname)
    {
        assert players != null : "(Team) Vorbedingung verletzt: players ist null";
        assert players.length == 8 : "(Team) Vorbedingung verletzt: players.length == 8";
        assert players[0] != null : "(Team) Vorbedingung verletzt: players[0] ist null";
        assert players[1] != null : "(Team) Vorbedingung verletzt: players[1] ist null";
        assert players[2] != null : "(Team) Vorbedingung verletzt: players[2] ist null";
        assert players[3] != null : "(Team) Vorbedingung verletzt: players[3] ist null";
        assert players[4] != null : "(Team) Vorbedingung verletzt: players[4] ist null";
        assert teamname != null : "(Team) Vorbedingung verletzt: teamname ist null";
        
        _players = players;
        _teamname = teamname;
    }
    
    /**
     * Calculates the AVG Elo of the Team.
     * 
     * @return The AVG Elo of the Team
     */
    public double calculateAvgElo()
    {
        double avgElo = 0;
        int i = 0;
        
        while(i <= 7 && _players[i] != null)
        {
            avgElo += _players[i].getElo();
            i++;
        }
        
        avgElo = avgElo / i;
        
        return avgElo;
    }

    /**
     * Gets the list of players.
     * 
     * @return the players
     * 
     * @ensure result != null
     */
    public Spieler[] getPlayers()
    {
        return _players;
    }

    /**
     * Sets the new list of players.
     * 
     * @param players the players to list
     * 
     * @require players != null
     * @require players.length == 8
     * @require players[0] != null
     * @require players[1] != null
     * @require players[2] != null
     * @require players[3] != null
     * @require players[4] != null
     */
    public void setPlayers(Spieler[] players)
    {
        assert players != null : "(Team) Vorbedingung verletzt: players ist null";
        assert players.length == 8 : "(Team) Vorbedingung verletzt: players.length == 8";
        assert players[0] != null : "(Team) Vorbedingung verletzt: players[0] ist null";
        assert players[1] != null : "(Team) Vorbedingung verletzt: players[1] ist null";
        assert players[2] != null : "(Team) Vorbedingung verletzt: players[2] ist null";
        assert players[3] != null : "(Team) Vorbedingung verletzt: players[3] ist null";
        assert players[4] != null : "(Team) Vorbedingung verletzt: players[4] ist null";
        
        this._players = players;
    }
    
    /**
     * Gets the current Teamname.
     * 
     * @return the Teamname
     * 
     */
    public String getTeamname()
    {
        return _teamname;
    }

    /**
     * Sets a new Teamname.
     * 
     * @param teamname the teamname to set
     * 
     * @require teamname != null
     * 
     * @ensure getTeamname() == teamname
     */
    public void setTeamname(String teamname)
    {
        assert teamname != null : "(Team) Vorbedingung verletzt: teamname ist null";
        this._teamname = teamname;
    }

    @Override
    public String toString()
    {
        String s = "Team: " + _teamname + " (Avg Elo: " + calculateAvgElo() + ") \n";
        for(Spieler p : _players)
        {
            if(p == null)
            {
                continue;
            }
            s += p.toString() + "\n";
        }
        
        return s + "\n";
    }

}
