package de.manta.black.turniersim.materialien;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Testclass for the Spieler-Class.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
class SpielerTest
{

    private Spieler _spieler;
    
    /**
     * Constructor.
     */
    public SpielerTest()
    {
        _spieler = new Spieler("BLM Ripper", 13, "Top");
    }
    
    /**
     * Tests the constructor.
     */
    @Test
    void constructorTest()
    {
        assertEquals("BLM Ripper", _spieler.getPlayerName());
        assertEquals(13, _spieler.getElo());
    }
    
    /**
     * Tests the getPlayerName() Method.
     */
    @Test
    void getPlayerNameTest()
    {
        assertEquals("BLM Ripper", _spieler.getPlayerName());
    }

    /**
     * Tests the getElo() Method.
     */
    @Test
    void getEloTest()
    {
        assertEquals(13, _spieler.getElo());        
    }
    
    /**
     * Tests the getElo() Method.
     */
    @Test
    void getPositionTest()
    {
        assertEquals("Top", _spieler.getPosition());        
    }
    
    /**
     * Tests the setPlayerName() Method.
     */
    @Test
    void setPlayerNameTest()
    {
        _spieler.setPlayerName("BLM CuV");
        assertEquals("BLM CuV", _spieler.getPlayerName());
        assertNotEquals("BLM CUV", _spieler.getPlayerName());
    }
    
    /**
     * Tests the setElo() Method.
     */
    @Test
    void setEloTest()
    {
        _spieler.setElo(14);
        assertEquals(14, _spieler.getElo());
        assertNotEquals(13, _spieler.getElo());     
    }
    
    /**
     * Tests the setPosition() Method.
     */
    @Test
    void setPositionTest()
    {
        _spieler.setPosition("Adc");
        assertEquals("Adc", _spieler.getPosition());
    }
}
