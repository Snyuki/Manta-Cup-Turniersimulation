package de.manta.black.turniersim.materialien;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Test Class for the Team-Class.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
class TeamTest
{
    private final Spieler s1 = new Spieler("BLM Ripper", 13, "Adc");
    private final Spieler s2 = new Spieler("BLM LRAT", 16, "Supp");
    private final Spieler s3 = new Spieler("BLM Öhm Ignöre", 15, "Top");
    private final Spieler s4 = new Spieler("BLM Mayb1e", 13, "Jngl");
    private final Spieler s5 = new Spieler("Chwischi", 16, "Mid");
    private final Spieler[] _players = new Spieler[] {s1, s2, s3, s4, s5, null, null, null};
    private final String TEAMNAME = "Testteam";
    private Team _team;
    
    /**
     * Constructor.
     */
    public TeamTest()
    {
        _team = new Team(_players, TEAMNAME);
    }
    
    /**
     * Tests the Constructor.
     */
    @Test
    void constructorTest()
    {
        assertEquals(_players, _team.getPlayers());
    }
    
    /**
     * Tests the calculateAvgElo() Method.
     */
    @Test
    void calculateAvgEloTest()
    {
        assertEquals(14.6, _team.calculateAvgElo());
    }

    /**
     * Tests the getPlayers() Method.
     */
    @Test
    void getPlayersTest()
    {
        assertEquals(_players, _team.getPlayers());
    }
    
    /**
     * Tests the setPlayers() Method.
     */
    @Test
    void setPlayersTest()
    {
        Spieler s6 = new Spieler("Lina", 15, "Sub1");
        Spieler[] players2 = _players.clone();
        players2[5] = s6;
        _team.setPlayers(players2);
        assertEquals(players2, _team.getPlayers());
    }
    
    /**
     * Tests the getTeamname() Method.
     */
    @Test
    void getTeamnameTest()
    {
        assertEquals(TEAMNAME, _team.getTeamname());
    }
    
    /**
     * Tests the setTeamname() Method.
     */
    @Test
    void setTeamnameTest()
    {
        String name = "NewTeamname";
        _team.setTeamname(name);
        assertEquals(name, _team.getTeamname());
    }
}
