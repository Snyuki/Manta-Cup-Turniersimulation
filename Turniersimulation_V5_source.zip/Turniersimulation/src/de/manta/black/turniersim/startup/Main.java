package de.manta.black.turniersim.startup;

import javax.swing.SwingUtilities;

import de.manta.black.turniersim.werkzeuge.SimWerkzeug;
import de.manta.black.turnierspagetti.FileHandler;
import de.manta.black.turnierspagetti.Simulation;
import de.manta.black.turnierspagetti.Window;

/**
 * Startup Class for the program
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class Main
{

    /**
     * 
     */
    public Main()
    {
        
    }

    /**
     * @param args
     */
    public static void main(String[] args)
    {
//        final SimWerkzeug simWerkzeug = new SimWerkzeug();
//        
//        SwingUtilities.invokeLater(new Runnable()
//        {
//            public void run()
//            {
//                simWerkzeug.showWindow();
//            }
//        });
        new Simulation();
    }

}
