package de.manta.black.turniersim.werkzeuge;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Represents the Team Panels for the different Teams.
 * There can be 12 Teams.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class TeamAuswahlWerkzeugUI
{
     private CardLayout _cLayout;
    
    private JPanel[] _teamPanels;
    private JTextField[] _playerNameFields;
    private JTextField[] _playerEloFields;
    
    private JTextField _teamNameTextField;
    
    /**
     * Constructor.
     */
    public TeamAuswahlWerkzeugUI()
    {
        _teamPanels = new JPanel[TConstants.TEAM_COUNT];
        
        createTeamViewPanel();
    }

    /**
     * Creates the Player Name Text Fields and lists them in the corresponding variable.
     */
    private JTextField[] createPlayerNameFields()
    {
        JTextField[] playerNameFields = new JTextField[12];
        
        for(int i = 0; i < 12; i++)
        {
            playerNameFields[i] = createPlayerTextField();
        }
        
        return playerNameFields;
    }

    /**
     * Creates the Player Elo Text Fields and lists them in the corresponding variable. 
     */
    private JTextField[] createPlayerELOFields()
    {
        JTextField[] playerEloFields = new JTextField[12];
        
        for(int i = 0; i < 12; i++)
        {
            playerEloFields[i] = createPlayerTextField();
        }
        
        return playerEloFields;
    }

    /**
     * Creates a Team Panel.
     * 
     * @return A Team Panel
     */
    private void createTeamViewPanel()
    {
        for(int i = 0; i < TConstants.TEAM_COUNT; i++)
        {
            JPanel panel = new JPanel();
            panel.setLayout(null);
//            panel.setBackground(UIConstants.BACKGROUND_COLOR);
            panel.setBackground(Color.BLUE);
            
            panel.add(createTeamNameTextField());
            
            for(JTextField jtf : createPlayerNameFields())
            {
                panel.add(jtf);
            }
            
            for(JTextField jtf : createPlayerELOFields())
            {
                panel.add(jtf);
            }
            
            _teamPanels[i] = panel;
        }
    }

    /**
     * Creates a Player Text field.
     * 
     * @return A Player Text Field
     */
    private JTextField createPlayerTextField()
    {
        JTextField jtf = new JTextField();
        jtf.setSize(200, 50);
        return jtf;
    }
    
    /**
     * Creates the Team Name Text Field.
     */
    private JTextField createTeamNameTextField()
    {
        JTextField jtf = new JTextField("Test");
        jtf.setSize(300, 100);
        _teamNameTextField = jtf;
        
        return jtf;
        
    }


    /**
     * Returns the Team Panels.
     * 
     * @return A List of the Team Panels.
     */
    public JPanel[] getUIPanels()
    {
        return _teamPanels;
    }
}
