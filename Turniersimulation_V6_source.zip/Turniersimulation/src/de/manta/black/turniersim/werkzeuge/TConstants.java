package de.manta.black.turniersim.werkzeuge;

/**
 * This Class holds constants for the Simulation.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class TConstants
{
    public static final String[] TEAMS = new String[] {"Team One", "Team Two", "Team Three", "Team Four", "Team Five",
            "Team Six", "Team Seven", "Team Eight", "Team Nine", "Team Ten", "Team Eleven", "Team Twelve"};

    public static final int APP_VERSION = 6;
    
    public static final int TEAM_COUNT = 12;
    public static final int TEAM_SIZE = 5;
    
    public static final int MAIN_ROSTER_COUNT = 5;
    
    public static final String TOP = "Top";
    public static final String JNGL = "Jngl";
    public static final String MID = "Mid";
    public static final String ADC = "Adc";
    public static final String SUPP = "Supp";
    
    public static final int MVP_PROBABILITY_FIRST = 60;
    public static final int MVP_PROBABILITY_SECOND = 25;
    public static final int MVP_PROBABILITY_THIRD = 10;
    public static final int MVP_PROBABILITY_FOURTH = 5;

    /**
     * A uniform indent
     */
    public static final String INDENT = "    ";
    
    
    /**
     * 
     */
    public TConstants()
    {
    }

    
}
