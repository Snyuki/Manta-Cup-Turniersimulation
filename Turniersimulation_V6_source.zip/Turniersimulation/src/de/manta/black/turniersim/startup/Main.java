package de.manta.black.turniersim.startup;

/**
 * Startup Class for the program
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class Main
{

    /**
     * 
     */
    public Main()
    {
        
    }

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        new Simulation();
    }

}
