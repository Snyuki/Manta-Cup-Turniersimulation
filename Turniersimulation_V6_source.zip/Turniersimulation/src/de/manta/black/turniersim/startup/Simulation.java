package de.manta.black.turniersim.startup;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

import de.manta.black.turniersim.materialien.Spieler;
import de.manta.black.turniersim.materialien.Team;
import de.manta.black.turniersim.services.ConfigService;
import de.manta.black.turniersim.services.FileHandler;
import de.manta.black.turniersim.services.MatchService;
import de.manta.black.turniersim.services.TeamService;
import de.manta.black.turniersim.services.TournamentService;
import de.manta.black.turniersim.services.model.NoTeamsYetException;
import de.manta.black.turniersim.services.model.TournamentResult;
import de.manta.black.turniersim.ui.DisplayWinnerDialog;
import de.manta.black.turniersim.ui.JTeamPanel;
import de.manta.black.turniersim.ui.SwingWorkerCancelWaiter;
import de.manta.black.turniersim.ui.Window;
import de.manta.black.turniersim.werkzeuge.TConstants;

/**
 * @version 05.04.2022
 * @author Jonas Müller
 *
 */
public class Simulation
{   
    
    /**
     * A Highlighter String
     */
    public static final String HIGHLIGHTER = "-------------------------";
    
    /**
     * The total number of tournaments that should be shown in the table
     * while multi-simulating.
     * 
     * Cant be a long since the scollToEnd() function wouldnt work anymore.
     */
    static final int MAX_TOURNAMENTS_AT_ONCE = 5000000;

    /** The Tournament Service handling everything in a tournament */
    private final TournamentService _tournamentService;
    private final MatchService _matchService;
    private final TeamService _teamService;
    private final ConfigService _configService;
    
    // The Simulation GUI
    private Window _simulationWindow;
    private FileHandler _handler;
    private JFrame _frame;
    private DisplayWinnerDialog _displayFrame;

    private SwingWorker<Void, String> _worker;
    
    /**
     * Simulates the Tournament
     */
    public Simulation()
    {
        _handler = new FileHandler();
        _simulationWindow = new Window(_handler);
        _frame = new JFrame();
        
        _handler.setUpEnviroment();
        addListeners();
        _teamService = new TeamService();
        _configService = new ConfigService();
        _matchService = new MatchService(_handler, _teamService);
        _tournamentService = new TournamentService(_handler, _matchService);
        _simulationWindow.showFrame();
        
        try
        {
            // Wait so panels can be initialized correctly
            Thread.sleep(200);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        _simulationWindow.updateTeamPanels();
    }

    /*
     * TODO Current Tasks
     * XXX Winrate per team
     * XXX Multisimulate -> Wie oft hat jedes Team gegen ein anderes Team gewonnen / verloren
     * XXX Multisimulate -> Durchschnittliche Platzierung in der eigenen Gruppe
     * XXX Add Wins of the Team to the Table representation
     * 
     * EXTRA Cancel und Resume Multisimulate (do with return numberOfDoneSims -> Add up to what it should simulate)
     * XXX Make Tiebreaker optional for performance
     * XXX Create Menu bar
     * XXX Limit CPU Usage of the program
     */
    
    /*
     * MC3 Make the Max tournaments at once variable changeable for the user
     * MC3 Teamanzahl als Konstante festhalten um Skalierbarkeit zu erreichen
     */
    
    /**
     * Simulates a certain number of Tournaments and logs
     * the results into a log file.
     * 
     * @param teams The participating teams
     * @param n The total number of tournaments
     * @param nMax The number of tournaments that should be shown in the window
     */
    public void simulateNTournaments(Team[] teams, long n, long nMax)
    {
        Map<Team, int[]> winTracker = new HashMap<>();
        Map<String, SortedMap<Spieler, int[]>> mvpTracker = new HashMap<>();
        
        for(Team team : teams)
        {
            winTracker.put(team, new int[8]);
            // Init lane Maps as sorted map by position top to bot
            mvpTracker.put(team.getTeamname(), 
                new TreeMap<Spieler, int[]>(new Comparator<Spieler>() {
                    public int compare(Spieler p1, Spieler p2) {
                        return _teamService.comparePositions(p1.getPosition(), p2.getPosition());
                    }
                })
            );
                
            for (Spieler spieler : team.getPlayers()) {
                mvpTracker.get(team.getTeamname()).put(spieler, new int[1]);
            }
        }

        try
        {
            TournamentResult tournamentResult;
            Team winner;
            
            for(int i = 0; i < n; i++)
            {   
                if(_worker.isCancelled())
                {
                    n = i;
                    break;
                }
                
                if(i % nMax == 0 && (n - 1) != i)
                {
                    _displayFrame.removeAllRows();
                }
                
                tournamentResult = _tournamentService.simulateTournament(teams, n);
                winner = tournamentResult.getSimulatedTournament()[1][0];

                for(int j = 0; j < tournamentResult.getSimulatedTournament()[0].length; j++)
                {
                    // j = 0 -> Winner++; j = 1 -> 2nd Place++; ...
                    winTracker.get(tournamentResult.getSimulatedTournament()[0][j])[j]++;
                }
                mvpTracker.get(tournamentResult.getMvp().getTeam())
                    .get(tournamentResult.getMvp().getSpieler())[0]++;

                _displayFrame.addWinner(winner);
            }
        }
        catch (IllegalStateException ise) {
            JOptionPane.showMessageDialog(null, ise.getMessage() 
                    + "\nPlease see the error log for detailed information.",
                   "Error while Simulating",
                   JOptionPane.ERROR_MESSAGE);
        }
        
        _displayFrame.updateProgressBar();
        _displayFrame.updateRemainingTime();
        _displayFrame.scrollToEnd();
        
        writeResultsToLog(winTracker, mvpTracker, n);
    }
    
    private void writeResultsToLog(Map<Team, int[]> winTracker, Map<String, SortedMap<Spieler, int[]>> mvpTracker,
            long totalNumberOfTournaments) {
        String titleString = "Total Placements of " + totalNumberOfTournaments
                + " Simulations: (Wins, 2nd, 3rd, 4th, Quarter participations)\n";
        String winString = "";
        
        String[] mvpStringArray;
        String[] winStringArray;
        
        for(Map.Entry<Team, int[]> entry : winTracker.entrySet())
        {
            mvpStringArray = new String[5];
            winStringArray = new String[6];
            
            int[] placings = entry.getValue();
            winStringArray[0] = entry.getKey().getTeamname() + ": ";
            winStringArray[1] = placings[0] + " Wins ["
                                    + _tournamentService.calculatePercentageOfAllGames(placings[0]) + "%]";
            winStringArray[2] = placings[1] + "";
            winStringArray[3] = placings[2] + "";
            winStringArray[4] = "" + placings[3];
            winStringArray[5] = "" + (placings[4] + placings[5] + placings[6] + placings[7]);
            
            String winStringTmp = String.format("%-4s %-22s %-10s %-10s %-10s %-10s", winStringArray[0], 
                    winStringArray[1], winStringArray[2], winStringArray[3], winStringArray[4], 
                    winStringArray[5]);
            
            int i = 0;
            for(Entry<Spieler, int[]> mvpEntry : mvpTracker.get(entry.getKey().getTeamname()).entrySet()) 
            {
                mvpStringArray[i] = mvpEntry.getValue()[0] + " ["
                                + _tournamentService.calculatePercentageOfAllGames(mvpEntry.getValue()[0])
                                + "%]";
                i++;
            }
            
            String mvpString = String.format("%-15s %-15s %-15s %-15s %-15s \r", mvpStringArray[0],
                    mvpStringArray[1], mvpStringArray[2], mvpStringArray[3], mvpStringArray[4]);
            // Remove somehow appended \n-char through String.format
            mvpString = mvpString.substring(0, mvpString.length() - 2);
            winString += String.format("%66s %10s MVPs: %70s \r", winStringTmp, TConstants.INDENT, mvpString);
        }
        
        winString = titleString + winString + "\n\n ----------------------------- \n";
        
        _handler.writeMultiLog(winString);
    }
    
    /**
     * Processes the tournaments in the background with a SwingWorker,
     * while keeping the responsability of the Application stable.
     * 
     * @param numberOfTournaments The number of tournaments to be simulated
     */
    private void processInBackground(long numberOfTournaments)
    {
        _worker = new SwingWorker<Void, String>() {
            
            @Override
            protected Void doInBackground() throws Exception
            {   
                long startTime = System.nanoTime(); 
                simulateNTournaments(_simulationWindow.getTeams(), numberOfTournaments, MAX_TOURNAMENTS_AT_ONCE);
                long endTime = System.nanoTime(); 
                long elapsed = endTime - startTime;
                System.out.println(TimeUnit.NANOSECONDS.toSeconds(elapsed) + "s elapsed.");
                return null;
            }
        };
        

        _displayFrame = new DisplayWinnerDialog(_simulationWindow.getFrame(), numberOfTournaments, _configService);
        addDisplayDialogListeners();
        
        _worker.addPropertyChangeListener(new SwingWorkerCancelWaiter(_displayFrame.getDialog()));
        _worker.execute();
        _displayFrame.openWindow();
    }
    
    /**
     * Adds the Listeners to the Window.
     */
    private void addListeners()
    {
        for (JTeamPanel teamPanel : _simulationWindow.getTeamPanels())
        {
            teamPanel.getSave().addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {                    
                    // Update Panel Name
                    String teamName = teamPanel.getTeamNameField().getText();
                    int index = _simulationWindow.getMainPane().getSelectedIndex();
                    _simulationWindow.getMainPane().setTitleAt(index, teamName);
                    
                    // Recalculate Avg Elo
                    try
                    {
                        double avgElo = _simulationWindow.calculateAvgElo(teamPanel.getElos());
                        teamPanel.setAvgElo(avgElo);   
                    }
                    catch (NumberFormatException e1)
                    {
                        JOptionPane.showMessageDialog(_frame, "Please enter only numbers!", "Alert",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        }
        
        _simulationWindow.getSimulateButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (!checkForAllTeamsHaveTeamnames()) return;
                
                _handler.writeLog("\n\n" + HIGHLIGHTER + " Tournament " + HIGHLIGHTER, 1);
                Team[][] simulatedBrackets = _tournamentService.simulateBrackets(_simulationWindow.getTeams());
                updateBrackets(simulatedBrackets[0], simulatedBrackets[1]);
                Team[][] simulatedPlayoffs = _tournamentService.simulatePlayoffs(simulatedBrackets[0], simulatedBrackets[1]);
                updatePlayoffTree(simulatedPlayoffs[1], simulatedPlayoffs[2], simulatedPlayoffs[3],
                        simulatedPlayoffs[4][0], simulatedPlayoffs[5][0]);

            }
        });
        
        _simulationWindow.getMultiSimulateButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (!checkForAllTeamsHaveTeamnames()) return;
                
                try 
                {
                    String input = JOptionPane.showInputDialog("How many Tournaments should be simulated?");
                    if (input == null || input.isBlank()) return;
                    long n = Long.parseLong(input);
                    processInBackground(n);
                }
                catch (NumberFormatException e2)
                {
                    JOptionPane.showMessageDialog(_frame, "Please enter only numeric characters!",
                            "Error!", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getClearLogButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object[] options = {"Simulation Log", "Multi Log"};
                String question = "Which log do you want to clear?";
                String title = "Clear log file";
                int messageType = JOptionPane.QUESTION_MESSAGE;
                String answer = (String) JOptionPane.showInputDialog(_frame, question, title, messageType, null, options, 0);
                
                if(answer == options[0])
                {
                    _handler.clearLog(FileHandler.LOG_PATH);
                }
                else if(answer == options[1])
                {

                    _handler.clearLog(FileHandler.MULTI_PATH);
                }
                
                if(answer != null)
                {
                    JOptionPane.showMessageDialog(_frame, "Log Cleared!", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getShowLogButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object[] options = {"Simulation Log", "Multi Log"};
                String question = "Which log do you want to open?";
                String title = "Open log file";
                int messageType = JOptionPane.QUESTION_MESSAGE;
                String answer = (String) JOptionPane.showInputDialog(_frame, question, title, messageType, null, options, 0);
                
                try
                {
                    if(answer == options[0])
                    {
                        _handler.openLogFile(FileHandler.LOG_PATH);
                    }
                    else if(answer == options[1])
                    {
    
                        _handler.openLogFile(FileHandler.MULTI_PATH);
                    }
                }
                catch (IOException e1) 
                {
                    JOptionPane.showMessageDialog(_frame, "Something went wrong opening the log!", "Error", 
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        _simulationWindow.getFrame().addWindowListener(new WindowAdapter()
        {
            // Writes all the Team Data into JSON File on Closing the Window
            // Note that Teamnames must not be equal
            @Override
            public void windowClosing(WindowEvent e)
            {
                if(_worker != null)
                {
                    _worker.cancel(true);
                }
                _handler.writeTeams(_simulationWindow.getTeams());
                _handler.writeConfig(_configService.getConfig());
            }
            
            @Override
            public void windowOpened(WindowEvent e) 
            {
                Team[] teams;
                try
                {
                    teams = _handler.readTeams();
                    _configService.setConfig(_handler.readConfig());
                    _simulationWindow.setUpTeams(teams);
                }
                catch (NoTeamsYetException e1)
                {
                    // DO Nothing
                }
            }
        });
    }
    
    /**
     * Adds the Listeners to the Dialog.
     */
    private void addDisplayDialogListeners()
    {
        _displayFrame.getCloseButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if(!_worker.isCancelled() && !_worker.isDone())
                    {
                    int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                                    "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if(answer == JOptionPane.NO_OPTION)
                    {
                        return;
                    }
                }
                _worker.cancel(true);
                _displayFrame.closeWindow();
            }
        });
        
        _displayFrame.getStopButton().addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if(_worker.isCancelled() || _worker.isDone()) return;
                int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                        "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if(answer == JOptionPane.NO_OPTION)
                {
                    return;
                }
                _worker.cancel(true);
            }
        });
        
        _displayFrame.getToggleTableCheckbox().addItemListener(new ItemListener()
        {
            
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    _displayFrame.toggleScrollPane(false);
                } else if (e.getStateChange() == ItemEvent.DESELECTED) {
                    _displayFrame.toggleScrollPane(true);
                }
                
            }
        });
        
        _displayFrame.getDialog().addWindowListener(new WindowAdapter()
        {
            // Writes all the Team Data into JSON File on Closing the Window
            // Note that Teamnames must not be equal
            @Override
            public void windowClosing(WindowEvent e)
            {
                if(_worker == null || _worker.isCancelled() || _worker.isDone())
                {
                    _displayFrame.closeWindow();
                    return;
                }
                
                int answer = JOptionPane.showConfirmDialog(_displayFrame, "Do you really want to stop the simulation?",
                        "Stop simulation?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if(answer == JOptionPane.NO_OPTION)
                {
                    return;
                }
                _worker.cancel(true);
                _displayFrame.closeWindow();
            }
        });
    }

    private boolean checkForAllTeamsHaveTeamnames()
    {
        _simulationWindow.updateTeamPanels();
        if (Arrays.asList(_simulationWindow.getTeams())
                .stream().anyMatch(team -> team.getTeamname().isBlank())) 
        {
            JOptionPane.showMessageDialog(_frame, "Alle Teams müssen einen Teamnamen haben!");
            return false;
        }
        return true;
    }
    
    /**
     * Updates the Bracket Tables.
     * 
     * @param simulatedLB The simulated Upper Bracket
     * @param simulatedUB The simulated Lower Bracket
     */
    private void updateBrackets(Team[] simulatedUB, Team[] simulatedLB)
    {
        _simulationWindow.updateBrackets(simulatedUB, simulatedLB);
        
    }
    
    /**
     * Updates the Playoff Tree acording to the participants.
     * 
     * @param quarterParticipants The Team participating in the quarterfinals
     * @param quarterTeams The Teams winning the quarterfinals
     * @param semisTeams The Teams winning the semifinals
     * @param thirdPlaceWinner The Team that won the third place match
     * @param finalTeam The Team winning the finals
     */
    private void updatePlayoffTree(Team[] quarterParticipants, Team[] quarterTeams, Team[] semisTeams, Team thirdPlaceWinner, Team finalTeam)
    {
        _simulationWindow.updatePlayoffTree(quarterParticipants, quarterTeams, semisTeams, thirdPlaceWinner, finalTeam);
    }
    
    
}
