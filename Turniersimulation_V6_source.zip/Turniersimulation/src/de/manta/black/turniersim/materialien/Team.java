package de.manta.black.turniersim.materialien;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import de.manta.black.turniersim.werkzeuge.TConstants;

/**
 * This Class represents a Team.
 * A Team consists of 5-8 players and has a Teamname.
 * 
 * @version 31.03.2022
 * @author Jonas Müller
 *
 */
public class Team
{

    /**
     * A list of all players on the team.
     */
    private Spieler[] _players;
    
    /**
     * The Teamname of the team
     */
    private String _teamname;
    
    private ArrayList<Double> _laneProbabilities;
    private List<Double> _scaledLaneProbabilities;
    private double _sumOfLaneProbabilities;
    
    /**
     * Constructor.
     * The passed list of the players has to have a length of 8.
     * 
     * 
     * @param players A list of all players on the Team
     * @param teamname The Teamname
     * 
     * @require players != null
     * @require players.length == 5
     * @require players[0] != null
     * @require players[1] != null
     * @require players[2] != null
     * @require players[3] != null
     * @require players[4] != null
     * @require teamname != null
     * 
     * @ensure getPlayers() == players
     * @ensure getTeamname() == teamname
     * 
     */
    public Team(Spieler[] players, String teamname)
    {
        assert players != null : "(Team) Vorbedingung verletzt: players ist null";
        assert players.length == TConstants.TEAM_SIZE : "(Team) Vorbedingung verletzt: players.length == 5";
        assert players[0] != null : "(Team) Vorbedingung verletzt: players[0] ist null";
        assert players[1] != null : "(Team) Vorbedingung verletzt: players[1] ist null";
        assert players[2] != null : "(Team) Vorbedingung verletzt: players[2] ist null";
        assert players[3] != null : "(Team) Vorbedingung verletzt: players[3] ist null";
        assert players[4] != null : "(Team) Vorbedingung verletzt: players[4] ist null";
        assert teamname != null : "(Team) Vorbedingung verletzt: teamname ist null";
        
        _players = players;
        _teamname = teamname;
        
        _laneProbabilities = new ArrayList<>();
        for (Spieler p : players) {
            _laneProbabilities.add((double) (p.getElo().getEloAsInt()));
        }
        _sumOfLaneProbabilities = _laneProbabilities.stream().reduce(0d, (a, b) -> a + b);;
        _scaledLaneProbabilities = _laneProbabilities.stream()
                .map(prob -> prob / _sumOfLaneProbabilities * 100).collect(Collectors.toList());
    }
    
    /**
     * Calculates the AVG Elo of the Team.
     * 
     * @return The AVG Elo of the Team
     */
    public double calculateAvgElo()
    {
        double avgElo = 0;
        int i = 0;
        
        while(i < TConstants.TEAM_SIZE && _players[i] != null)
        {
            avgElo += _players[i].getElo().getEloAsInt();
            i++;
        }
        
        avgElo = avgElo / i;
        
        return avgElo;
    }

    /**
     * Gets the list of players.
     * 
     * @return the players
     * 
     * @ensure result != null
     */
    public Spieler[] getPlayers()
    {
        return _players;
    }
    
    /**
     * Returns the probabilities of each lane as double in an ArrayList.
     * 
     * @return The laneProbabilities
     */
    public ArrayList<Double> getLaneProbabilities() {
        return _laneProbabilities;
    }
    
    /**
     * Returns the probabilities of each lane as double in an ArrayList scaled to 100%.
     * 
     * @return The scaledLaneProbabilities
     */
    public List<Double> getScaledLaneProbabilities() {
        return _scaledLaneProbabilities;
    }
    
    /**
     * Returns the sum of the probabilities of each lane as double.
     * 
     * @return The sumOfLaneProbabilities
     */
    public double getSumOfLaneProbabilities() {
        return _sumOfLaneProbabilities;
    }

    /**
     * Sets the new list of players.
     * 
     * @param players the players to list
     * 
     * @require players != null
     * @require players.length == 8
     * @require players[0] != null
     * @require players[1] != null
     * @require players[2] != null
     * @require players[3] != null
     * @require players[4] != null
     */
    public void setPlayers(Spieler[] players)
    {
        assert players != null : "(Team) Vorbedingung verletzt: players ist null";
        assert players.length == TConstants.TEAM_SIZE : "(Team) Vorbedingung verletzt: players.length == 5";
        assert players[0] != null : "(Team) Vorbedingung verletzt: players[0] ist null";
        assert players[1] != null : "(Team) Vorbedingung verletzt: players[1] ist null";
        assert players[2] != null : "(Team) Vorbedingung verletzt: players[2] ist null";
        assert players[3] != null : "(Team) Vorbedingung verletzt: players[3] ist null";
        assert players[4] != null : "(Team) Vorbedingung verletzt: players[4] ist null";
        
        this._players = players;
    }
    
    /**
     * Gets the current Teamname.
     * 
     * @return the Teamname
     * 
     */
    public String getTeamname()
    {
        return _teamname;
    }

    /**
     * Sets a new Teamname.
     * 
     * @param teamname the teamname to set
     * 
     * @require teamname != null
     * 
     * @ensure getTeamname() == teamname
     */
    public void setTeamname(String teamname)
    {
        assert teamname != null : "(Team) Vorbedingung verletzt: teamname ist null";
        this._teamname = teamname;
    }

    @Override
    public String toString()
    {
        String s = "Team: " + _teamname + " (Avg Elo: " + calculateAvgElo() + ") \n";
        for(Spieler p : _players)
        {
            if(p == null)
            {
                continue;
            }
            s += p.toString() + "\n";
        }
        
        return s + "\n";
    }
}
