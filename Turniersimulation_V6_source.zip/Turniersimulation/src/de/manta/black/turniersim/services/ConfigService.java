package de.manta.black.turniersim.services;

import de.manta.black.turniersim.services.model.SimulationConfig;

/**
 * Handles the Config of the Application
 * 
 * @version 27.12.2023
 * @author Jonas Müller
 *
 */
public class ConfigService
{
    private SimulationConfig _config;

    /**
     * @return the config
     */
    public SimulationConfig getConfig()
    {
        return _config;
    }

    /**
     * @param config the config to set
     */
    public void setConfig(SimulationConfig config)
    {
        this._config = config;
    }
}
