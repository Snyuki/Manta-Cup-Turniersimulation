package de.manta.black.turniersim.services;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

import de.manta.black.turniersim.materialien.Team;
import de.manta.black.turniersim.services.model.Mvp;
import de.manta.black.turniersim.services.model.TournamentResult;
import de.manta.black.turniersim.startup.Simulation;
import de.manta.black.turniersim.werkzeuge.TConstants;

/**
 * The Service Class which handles all the logic regarding the Matches
 * in a tournament.
 * To simulate a tournament call simulateTournament(teams).
 * To simulate only the brackets call simulateBrackets(teams).
 * To simulate only the playoffs call simulatePlayoffs(firstBracket, secondBracket).
 * 
 * @version 19.04.2022
 * @author Jonas Müller
 *
 */
public class TournamentService
{
    
    /** The FileHandler of the Program */
    private FileHandler _handler;
    
    private MatchService _matchService;
    
    /** The number of tournaments that should be simulated */
    private long _numberOfTournaments;

    private Map<Integer, Double> percentageCache = new HashMap<>();
    private Map<Double, Long> eloRoundedCache = new HashMap<>();
    /**
     * Constructor.
     * 
     * @param handler The FileHandler of the Program
     * @param matchService The MatchService of the Program
     */
    public TournamentService(FileHandler handler, MatchService matchService)
    {
        this._handler = handler;
        this._matchService = matchService;
    }
    
    /**
     * Simulates the Tournament with the given Teams.
     * It logs the detailed information about each game only if the numberOfTournaments is
     * below 10.
     * It returns an array with all placements and the winning team.
     * The array with all placements has the following structure:
     * 0. - 3.: Quarter loosers
     * 4.: 4th Place
     * 5.: 3rd Place
     * 6.: 2nd Place
     * 7.: 1st Place
     * 
     * @param teams The teams of the tournament
     * @param numberOfTournaments The number of tournaments that should be simulated
     * 
     * @return An Array with {all placements, the winning team}
     */
    public TournamentResult simulateTournament(Team[] teams, long numberOfTournaments)
    {
        this._numberOfTournaments = numberOfTournaments;
        TournamentResult tournamentResult = new TournamentResult();
        
        Team[][] simulatedBrackets;
        Team[][] simulatedPlayoffs;
        if(_numberOfTournaments >= 10)
        {
            simulatedBrackets = simulateBracketsNoLog(teams);
            simulatedPlayoffs = simulatePlayoffsNoLog(simulatedBrackets[0], simulatedBrackets[1]);
        } 
        else 
        {
            simulatedBrackets = simulateBrackets(teams);
            simulatedPlayoffs = simulatePlayoffs(simulatedBrackets[0], simulatedBrackets[1]);
        }
        
        tournamentResult.setSimulatedTournament(new Team[][] {simulatedPlayoffs[0], simulatedPlayoffs[4]});
        tournamentResult.setMvp(
                selectMvp(simulatedPlayoffs[5][0],
                        simulatedPlayoffs[5][1],
                        simulatedPlayoffs[5][2],
                        simulatedPlayoffs[5][3]));
        return tournamentResult;
    }
    
    /*
     *         Winner, Second-Place, Third-Place, Fourth-Place, Quarters, Group-First, Second, 3rd, 4th, 5th, 6th
     * Team 1: 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0
     * 
     * Return {Team winner, HashMap placements}
     * -> Try not to calculate winner by placements due to performance
     */

    /**
     * Simulates the Brackets and returns a two dimentsional Team Array
     * which holds the first Bracket in the 0th position and the second
     * Bracket in the 1st position.
     * 
     * @param teams The Teams participating
     * 
     * @return A Two Dimensional Array of the simulated Brackets
     */
    public Team[][] simulateBrackets(Team[] teams)
    {
        Team[] upperBracket = Arrays.copyOfRange(teams, 0, (teams.length / 2));
        Team[] lowerBracket = Arrays.copyOfRange(teams, teams.length / 2, teams.length);
        
        Team[][] simulatedBrackets = new Team[teams.length / (teams.length / 2)][teams.length / 2];
        _handler.writeLog("\n\n" + Simulation.HIGHLIGHTER + " Groupphase 1 " + Simulation.HIGHLIGHTER + "\n", 1);
        simulatedBrackets[0] = simulateBracket(upperBracket, true); // Simulate upper Bracket
        _handler.writeLog("\n\n" + Simulation.HIGHLIGHTER + " Groupphase 2 " + Simulation.HIGHLIGHTER + "\n", 1);
        simulatedBrackets[1] = simulateBracket(lowerBracket, true); // Simulate lower Bracket
        
        return simulatedBrackets;
    }
    
    /**
     * Simulates the Brackets and returns a two dimentsional Team Array
     * which holds the first Bracket in the 0th position and the second
     * Bracket in the 1st position.
     * 
     * @param teams The Teams participating
     * 
     * @return A Two Dimensional Array of the simulated Brackets
     */
    public Team[][] simulateBracketsNoLog(Team[] teams)
    {
        Team[] upperBracket = Arrays.copyOfRange(teams, 0, (teams.length / 2));
        Team[] lowerBracket = Arrays.copyOfRange(teams, teams.length / 2, teams.length);
        
        Team[][] simulatedBrackets = new Team[teams.length / (teams.length / 2)][teams.length / 2];
        simulatedBrackets[0] = simulateBracket(upperBracket, false); // Simulate upper Bracket
        simulatedBrackets[1] = simulateBracket(lowerBracket, false); // Simulate lower Bracket
        
        return simulatedBrackets;
    }
    
    /**
     * Simulates the Bracket.
     * 
     * Team 1 vs Team 2, 3, 4, 5, 6
     * Team 2 vs Team 3, 4, 5, 6
     * Team 3 vs Team 4, 5, 6
     * Team 4 vs Team 5, 6
     * Team 5 vs Team 6
     * 
     * @param bracket The bracket that is to be simulated
     * @param writeLog True if there should be log, else false
     * 
     * @return The simulated bracket
     */
    private Team[] simulateBracket(Team[] bracket, boolean writeLog)
    {
        /*
         * 1. Jedes Team | Wins
         * 2. simulate matches and fill 1.
         * 3. Return new Bracket (Array) with new seetings 
         */
        
        // Create Map that is to be updated while simulating
        Map<Team, Integer> bSimulation = new HashMap<>();
        
        // Initialize the Map
        for(int i = 0; i < bracket.length; i++)
        {
            bSimulation.put(bracket[i], 0);
        }
        
        // Simulate Matches
        for(int i = 0; i < bracket.length - 1; i++)
        {
            for(int j = 1 + i; j < bracket.length; j++)
            {
                if(_matchService.simulateMatch(bracket[i], bracket[j], 1, _numberOfTournaments))
                {
                    bSimulation.put(bracket[i], bSimulation.get(bracket[i]) + 1);
                }
                else
                {
                    bSimulation.put(bracket[j], bSimulation.get(bracket[j]) + 1);                    
                }
            }
        }
        
        Team[] simulatedBracket = new Team[bracket.length];
        Map<Team, Integer> bSimulationCopy = new HashMap<>(bSimulation);
        // Evaluate Bracket Simulation
        for(int i = 0; i < bracket.length; i++)
        {
            Optional<Entry<Team, Integer>> highestEntry = bSimulationCopy.entrySet()
                    .stream()
                    .max(Comparator.comparing(Map.Entry::getValue));
            
            bSimulationCopy.remove(highestEntry.get().getKey());
            // XXX Value represents the wins of the Team. --> Use Later
            simulatedBracket[i] = highestEntry.get().getKey();
        }

        // Add Here: if(tiebreaker) {
        
        // Tiebreaker check if 4th and 5th have same wins
        if(bSimulation.get(simulatedBracket[3]) == bSimulation.get(simulatedBracket[4]))
        {
            if(writeLog)
            {
                _handler.writeLog(Simulation.HIGHLIGHTER + " Tiebreaker " + Simulation.HIGHLIGHTER, 0);
            }
            // Swap places if second team won
            if(!simualteBo(3, simulatedBracket[3], simulatedBracket[4]))
            {
                Team looser = simulatedBracket[3];
                simulatedBracket[3] = simulatedBracket[4];
                simulatedBracket[4] = looser;
            }
        }
        
        return simulatedBracket;
    }

    /**
     * Simulates the Playoffs.
     * First there are the Quarterfinals played as a B03.
     * The Matching will be:
     * - Bracket 1: 1. Seet vs Bracket 2: 4th Seet
     * - Bracket 1: 2. Seet vs Bracket 2: 3th Seet
     * - Bracket 1: 3. Seet vs Bracket 2: 2th Seet
     * - Bracket 1: 4. Seet vs Bracket 2: 1th Seet
     * 
     * Secondly there are the Semifinals played as a B03.
     * Lastly there are the Finals played as a Bo5.
     * 
     * @param upperBracket The First Bracket
     * @param lowerBracket The Second Bracket
     * 
     * @return All Playoff-Placements and the participating teams in each round of the playoffs 
     */
    public Team[][] simulatePlayoffs(Team[] upperBracket, Team[] lowerBracket)
    {
        Team[] quarterParticipants = new Team[8];
        Team[] quarterWinners = new Team[4];
        Team[] semiWinners = new Team[2];
        Team[] semiLosers = new Team[2];
        Team thirdPlaceWinner = null;
        Team finalWinner = null;
        Team secondPlace = null;
        Team fourthPlace = null;
        
        // Participants
        quarterParticipants[0] = upperBracket[0];
        quarterParticipants[1] = upperBracket[2];
        quarterParticipants[2] = upperBracket[3];
        quarterParticipants[3] = upperBracket[1];
        quarterParticipants[4] = lowerBracket[3];
        quarterParticipants[5] = lowerBracket[1];
        quarterParticipants[6] = lowerBracket[0];
        quarterParticipants[7] = lowerBracket[2];
        
        // 1st, 2nd, 3rd, 4th, Quarters
        // 1, 1, 1, 1, 4
        Team[] koPlacements = new Team[8];
        
        _handler.writeLog("\n" + Simulation.HIGHLIGHTER + " Quarterfinals " + Simulation.HIGHLIGHTER + "\n", 1);
        
        // Quarters
        if(simualteBo(3, quarterParticipants[0], quarterParticipants[4]))
        {
            quarterWinners[0] = quarterParticipants[0];
            koPlacements[7] = quarterParticipants[4];
        }
        else
        {
            quarterWinners[0] = quarterParticipants[4];
            koPlacements[7] = quarterParticipants[0];
        }
        
        if(simualteBo(3, quarterParticipants[1], quarterParticipants[5]))
        {
            quarterWinners[1] = quarterParticipants[1];
            koPlacements[6] = quarterParticipants[5];
        }
        else
        {
            quarterWinners[1] = quarterParticipants[5];
            koPlacements[6] = quarterParticipants[1];
        }
        
        if(simualteBo(3, quarterParticipants[2], quarterParticipants[6]))
        {
            quarterWinners[2] = quarterParticipants[2];
            koPlacements[5] = quarterParticipants[6];
        }
        else
        {
            quarterWinners[2] = quarterParticipants[6];
            koPlacements[5] = quarterParticipants[2];
        }
        
        if(simualteBo(3, quarterParticipants[3], quarterParticipants[7]))
        {
            quarterWinners[3] = quarterParticipants[3];
            koPlacements[4] = quarterParticipants[7];
        }
        else
        {
            quarterWinners[3] = quarterParticipants[7];
            koPlacements[4] = quarterParticipants[3];
        }
        
        _handler.writeLog("\n" + Simulation.HIGHLIGHTER + " Semifinals " + Simulation.HIGHLIGHTER + "\n", 1);
        
        int j;
        // Semis
        for(int i = 0; i < 2; i++)
        {
            j = i * 2;
            if(simualteBo(3, quarterWinners[j], quarterWinners[j + 1]))
            {
                semiWinners[i] = quarterWinners[j];
                semiLosers[i] = quarterWinners[j + 1];
            }
            else
            {
                semiWinners[i] = quarterWinners[j + 1];
                semiLosers[i] = quarterWinners[j];
            }
        }

        // Game for 3rd Place
        _handler.writeLog("\n" + Simulation.HIGHLIGHTER + " Third Place Finals " + Simulation.HIGHLIGHTER + "\n", 1);
        if(simualteBo(5, semiLosers[0], semiLosers[1]))
        {
            thirdPlaceWinner = semiLosers[0];
            fourthPlace = semiLosers[1];
            koPlacements[3] = semiLosers[1];
            koPlacements[2] = thirdPlaceWinner;
        }
        else
        {
            thirdPlaceWinner = semiLosers[1];
            fourthPlace = semiLosers[0];
            koPlacements[3] = semiLosers[0];
            koPlacements[2] = thirdPlaceWinner;
        }
        
        // Finals
        _handler.writeLog("\n" + Simulation.HIGHLIGHTER + " Finals " + Simulation.HIGHLIGHTER + "\n", 1);
        
        if(simualteBo(5, semiWinners[0], semiWinners[1]))
        {
            finalWinner = semiWinners[0];
            secondPlace = semiWinners[1];
            koPlacements[1] = semiWinners[1];
            koPlacements[0] = finalWinner;
        }
        else
        {
            finalWinner = semiWinners[1];
            secondPlace = semiWinners[0];
            koPlacements[1] = semiWinners[0];
            koPlacements[0] = finalWinner;
        }
        
        // MVP
        Mvp mvp = selectMvp(finalWinner, secondPlace, thirdPlaceWinner, fourthPlace);
        _handler.writeLog("\nMVP: " + mvp.getSpieler().getPlayerName() + " ("
                + mvp.getTeam() + "/" + mvp.getSpieler().getPosition() + ")\n",  1);
        
        return new Team[][] {koPlacements, quarterParticipants, quarterWinners, semiWinners, {thirdPlaceWinner}, 
            {finalWinner, secondPlace, thirdPlaceWinner, fourthPlace}};
    }
    
    /**
     * Simulates the Playoffs.
     * First there are the Quarterfinals played as a B03.<br>
     * The Matching will be:<br>
     * - Bracket 1: 1. Seet vs Bracket 2: 4th Seet <br>
     * - Bracket 1: 2. Seet vs Bracket 2: 3th Seet <br>
     * - Bracket 1: 3. Seet vs Bracket 2: 2th Seet <br>
     * - Bracket 1: 4. Seet vs Bracket 2: 1th Seet <br>
     * <br>
     * Secondly there are the Semifinals played as a B03.<br>
     * Lastly there are the Finals played as a Bo5.
     * 
     * @param upperBracket The First Bracket
     * @param lowerBracket The Second Bracket
     * 
     * @return All Playoff-Placements and the participating teams in each round of the playoffs 
     */
    public Team[][] simulatePlayoffsNoLog(Team[] upperBracket, Team[] lowerBracket)
    {
        Team[] quarterParticipants = new Team[8];
        Team[] quarterWinners = new Team[4];
        Team[] semiWinners = new Team[2];
        Team[] semiLosers = new Team[2];
        Team thirdPlaceWinner = null;
        Team finalWinner = null;
        Team secondPlace = null;
        Team fourthPlace = null;
        
        // Participants
        quarterParticipants[0] = upperBracket[0];
        quarterParticipants[1] = upperBracket[2];
        quarterParticipants[2] = upperBracket[3];
        quarterParticipants[3] = upperBracket[1];
        quarterParticipants[4] = lowerBracket[3];
        quarterParticipants[5] = lowerBracket[1];
        quarterParticipants[6] = lowerBracket[0];
        quarterParticipants[7] = lowerBracket[2];
        

        // 1st, 2nd, 3rd, 4th, Quarters
        // 1, 1, 1, 1, 4
        Team[] koPlacements = new Team[8];
        
        // Quarters
        if(simualteBo(3, quarterParticipants[0], quarterParticipants[4]))
        {
            quarterWinners[0] = quarterParticipants[0];
            koPlacements[7] = quarterParticipants[4];
        }
        else
        {
            quarterWinners[0] = quarterParticipants[4];
            koPlacements[7] = quarterParticipants[0];
        }
        
        if(simualteBo(3, quarterParticipants[1], quarterParticipants[5]))
        {
            quarterWinners[1] = quarterParticipants[1];
            koPlacements[6] = quarterParticipants[5];
        }
        else
        {
            quarterWinners[1] = quarterParticipants[5];
            koPlacements[6] = quarterParticipants[1];
        }
        
        if(simualteBo(3, quarterParticipants[2], quarterParticipants[6]))
        {
            quarterWinners[2] = quarterParticipants[2];
            koPlacements[5] = quarterParticipants[6];
        }
        else
        {
            quarterWinners[2] = quarterParticipants[6];
            koPlacements[5] = quarterParticipants[2];
        }
        
        if(simualteBo(3, quarterParticipants[3], quarterParticipants[7]))
        {
            quarterWinners[3] = quarterParticipants[3];
            koPlacements[4] = quarterParticipants[7];
        }
        else
        {
            quarterWinners[3] = quarterParticipants[7];
            koPlacements[4] = quarterParticipants[3];
        }
        
        int j;
        // Semis
        for(int i = 0; i < 2; i++)
        {
            j = i * 2;
            if(simualteBo(3, quarterWinners[j], quarterWinners[j + 1]))
            {
                semiWinners[i] = quarterWinners[j];
                semiLosers[i] = quarterWinners[j + 1];
            }
            else
            {
                semiWinners[i] = quarterWinners[j + 1];
                semiLosers[i] = quarterWinners[j];
            }
        }

        // Game for 3rd Place
        if(simualteBo(5, semiLosers[0], semiLosers[1]))
        {
            thirdPlaceWinner = semiLosers[0];
            fourthPlace = semiLosers[1];
            koPlacements[3] = semiLosers[1];
            koPlacements[2] = thirdPlaceWinner;
        }
        else
        {
            thirdPlaceWinner = semiLosers[1];
            fourthPlace = semiLosers[0];
            koPlacements[3] = semiLosers[0];
            koPlacements[2] = thirdPlaceWinner;
        }
        
        // Finals
        if(simualteBo(5, semiWinners[0], semiWinners[1]))
        {
            finalWinner = semiWinners[0];
            secondPlace = semiWinners[1];
            koPlacements[1] = semiWinners[1];
            koPlacements[0] = finalWinner;
        }
        else
        {
            finalWinner = semiWinners[1];
            secondPlace = semiWinners[0];
            koPlacements[1] = semiWinners[0];
            koPlacements[0] = finalWinner;
        }
        
        return new Team[][] {koPlacements, quarterParticipants, quarterWinners, semiWinners, {thirdPlaceWinner}, 
            {finalWinner, secondPlace, thirdPlaceWinner, fourthPlace}};
    }
    
    /**
     * This methods selects a MVP for a tournament.
     * The selection is based on the following:
     * - 1st placed Team: 60%
     * - 2nd placed Team: 25%
     * - 3rd placed Team: 10%
     * - 4th placed Team: 5%
     * 
     * In the selected Team, the player is selected via the
     * players elo.
     * 
     * @param first The winning team
     * @param secondThe second placed team
     * @param third The third placed team
     * @param fourth The fourth placed team
     * 
     * @return The selected Mvp
     */
    private Mvp selectMvp(Team first, Team second, Team third, Team fourth) {
        
        int teamChoice = ThreadLocalRandom.current().nextInt(101);;
        
        if (teamChoice < TConstants.MVP_PROBABILITY_FIRST)
        {
            return selectPlayerFromTeamAsMvp(first);
        } 
        else if (teamChoice < TConstants.MVP_PROBABILITY_FIRST + TConstants.MVP_PROBABILITY_SECOND)
        {
            return selectPlayerFromTeamAsMvp(second);
        } 
        else if (teamChoice <TConstants.MVP_PROBABILITY_FIRST
                + TConstants.MVP_PROBABILITY_SECOND + TConstants.MVP_PROBABILITY_THIRD)
        {
            return selectPlayerFromTeamAsMvp(third);
        } 
        else
        {
            return selectPlayerFromTeamAsMvp(fourth);
        }
    }
    
    /**
     * Selects a player for Mvp based on the elos.
     * 
     * @param team The team
     * 
     * @return The selected Mvp
     */
    private Mvp selectPlayerFromTeamAsMvp(Team team) {
        Mvp mvp = new Mvp();
        mvp.setTeam(team.getTeamname());
        
        List<Double> laneProbabilities = team.getScaledLaneProbabilities();

        int playerChoice = ThreadLocalRandom.current().nextInt(101);;
        double playerProbability = 0;
        
        for (int i = 0; i < TConstants.TEAM_SIZE; i++) {
            playerProbability += laneProbabilities.get(i);
            if (playerChoice <= round(playerProbability)) {
                mvp.setSpieler(team.getPlayers()[i]);
                return mvp;
            }
        }
        
        IllegalStateException ise = new IllegalStateException("No MVP could be selected!");
        _handler.writeErrorLog("No MVP could be selected!", ise);
        throw ise;
    }
    
    /**
     * Simulates a BoX between two Teams.
     * 
     * @param boCount The Number of Games that will be played
     * @param team1 The first Team
     * @param team2 The second Team
     * 
     * @return True if Team 1 won, else false
     * 
     * @require boCount % 2 != 0
     */
    private boolean simualteBo(int boCount, Team team1, Team team2)
    {
        assert boCount % 2 != 0 : "(simualteBo) Vorbedingung verletzt: boCount % 2 != 0";
        
        int t1Win = 0;
        int t2Win = 0;
        
        int i = 0;
        
        while((i < boCount) && (t1Win < (boCount + 1) / 2) && (t2Win < (boCount + 1) / 2))
        {
            if(_matchService.simulateMatch(team1, team2, i + 1, _numberOfTournaments))
            {
                t1Win++;
            }
            else
            {
                t2Win++;
            }
            i++;
        }
        
        return t1Win > t2Win;
    }

    /**
     * Calculates what the percentage of the given int is, with the total amount of games
     * played.
     * 
     * @param percentageAsInt to be determined percentage as int
     * 
     * @return the percentage as double
     */
    public double calculatePercentageOfAllGames(int percentageAsInt)
    {
        if (percentageCache.containsKey(percentageAsInt)) {
            return percentageCache.get(percentageAsInt);
        }
        
        int scale = (int) Math.pow(10, 1);
        double percentage = (double) (percentageAsInt) / _numberOfTournaments * 100;
        percentage = (double) Math.round(percentage * scale) / scale;
        percentageCache.put(percentageAsInt, percentage);
        return percentage;
    }

    /**
     * Rounds a number similar to the {@link Math#round(double) round} function. But adding a cache
     * 
     * @param number The to be rounded number
     * 
     * @return The rounded number
     */
    private long round(double number) {
        if (eloRoundedCache.containsKey(number)) {
            return eloRoundedCache.get(number);
        }
        
        long rounded = Math.round(number);
        eloRoundedCache.put(number, rounded);
        return rounded;
    }
}
