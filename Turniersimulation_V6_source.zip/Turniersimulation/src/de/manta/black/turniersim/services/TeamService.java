package de.manta.black.turniersim.services;

import de.manta.black.turniersim.werkzeuge.TConstants;

/**
 * @version 20.12.2023
 * @author Jonas Müller
 *
 */
public class TeamService
{
    /**
     * Serializes a Position
     * 
     * @param position
     * 
     * @return The int value of the position
     */
    public int serializePosition(String position) {
        switch (position) {
        case TConstants.TOP: 
            return 1;
        case TConstants.JNGL:
            return 2;
        case TConstants.MID:
            return 3;
        case TConstants.ADC:
            return 4;
        case TConstants.SUPP:
            return 5;
        default: return 0;
        }
    }
    
    /**
     * Compares the two given positions.
     * 
     * @param p1 The first Position
     * @param p2 The second Position
     * 
     * @return the ordinal position by {@link Integer#compare(int, int) compare} standard
     */
    public int comparePositions(String p1, String p2) {
        return serializePosition(p1) - serializePosition(p2);
    }
}
