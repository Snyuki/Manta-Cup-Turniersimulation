package de.manta.black.turniersim.services.model;

import de.manta.black.turniersim.materialien.Team;

/**
 * @version 20.12.2023
 * @author Jonas Müller
 *
 */
public class TournamentResult
{
    private Mvp mvp;
    private Team[][] simulatedTournament;
    
    /**
     * @return the mvp
     */
    public Mvp getMvp()
    {
        return mvp;
    }
    
    /**
     * @return the simulatedTournament
     */
    public Team[][] getSimulatedTournament()
    {
        return simulatedTournament;
    }

    /**
     * @param mvp the mvp to set
     */
    public void setMvp(Mvp mvp)
    {
        this.mvp = mvp;
    }
    
    /**
     * @param simulatedTournament the simulatedTournament to set
     */
    public void setSimulatedTournament(Team[][] simulatedTournament)
    {
        this.simulatedTournament = simulatedTournament;
    }
    
        
}
