package de.manta.black.turniersim.services.model;

import java.util.HashMap;
import java.util.Map;

/**
 * The Elos accepted in this Tournament linked with a integerized
 * representation.
 * 
 * @version 20.12.2023
 * @author Jonas Müller
 *
 */
public enum EloRanking
{
    IRON4(1),
    IRON3(2),
    IRON2(3),
    IRON1(4),
    BRONZE4(5),
    BRONZE3(6),
    BRONZE2(7),
    BRONZE1(8),
    SILVER4(9),
    SILVER3(10),
    SILVER2(11),
    SILVER1(12),
    GOLD4(13),
    GOLD3(14),
    GOLD2(15),
    GOLD1(16),
    PLATINUM4(17),
    PLATINUM3(18),
    PLATINUM2(19),
    PLATINUM1(20),
    EMERALD4(21),
    EMERALD3(22),
    EMERALD2(23),
    EMERALD1(24),
    DIAMOND4(25),
    DIAMOND3(26),
    DIAMOND2(27),
    DIAMOND1(28),
    MASTER0(29),
    MASTER100(30),
    MASTER200(31),
    MASTER300(32);
    
    private final int eloAsInt;
    // Reverse-lookup map for getting a EloRanking from the elo value
    private static final Map<Integer, EloRanking> lookupMap = new HashMap<Integer, EloRanking>();
    
    static {
        for (EloRanking eloRank : EloRanking.values()) {
            lookupMap.put(eloRank.getEloAsInt(), eloRank);
        }
    }
    
    private EloRanking(int eloAsInt) {
        this.eloAsInt = eloAsInt;
    }
    
    /**
     * @return The Elo as Integer
     */
    public int getEloAsInt() {
        return this.eloAsInt;
    }
    
    /**
     * @return The Elo as String
     */
    public String getEloAsString() {
        return Integer.toString(this.eloAsInt);
    }
    
    /**
     * @param eloRanking The wanted Elo Ranking as an Int
     * 
     * @return The mapped EloRanking
     */
    public static EloRanking get(Integer eloRanking) {
        if (eloRanking == null) return null;
        return lookupMap.get(eloRanking);
    }
}
