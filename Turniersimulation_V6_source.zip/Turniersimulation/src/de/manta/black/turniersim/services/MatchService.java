package de.manta.black.turniersim.services;

import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ThreadLocalRandom;

import de.manta.black.turniersim.materialien.Spieler;
import de.manta.black.turniersim.materialien.Team;
import de.manta.black.turniersim.services.model.FaceOffResult;
import de.manta.black.turniersim.werkzeuge.TConstants;

/**
 * Handles all matters regarding a match
 * 
 * @version 20.12.2023
 * @author Jonas Müller
 *
 */
public class MatchService
{
    private final FileHandler _handler;
    private final TeamService _teamService;
    
    /**
     * @param handler The file handler
     * @param teamService The team service
     */
    public MatchService(FileHandler handler, TeamService teamService)
    {
        _handler = handler;
        _teamService = teamService;
    }

    /**
     * Simulates a match between two Teams.
     * 
     * Calculates the winner by making a stochastic prediction after
     * adjusting the probability to win for the teams based of a 
     * exponential function.
     * 
     * There will be five predictions per match. One for each spot
     * in the Main Roster. Simulating a face of on each lane.
     * The winner will be the Team with the most lane wins.
     * 
     * Note that if the average elo difference between the two players
     * is too big, the lower elo team has always still a 0.5% chance
     * to win.
     * 
     * @param team The first competetor
     * @param team2 The second competetor
     * @param boNumber The Gamenumber of the Match
     * @param numberOfTournaments The total number of Tournaments to be simulated
     * 
     * @return True if Team1 won, else false
     */
    public boolean simulateMatch(Team team, Team team2, int boNumber, long numberOfTournaments)
    {
        // Init a map sorted by position (top to bot)
        SortedMap<String, FaceOffResult> results = new TreeMap<String, FaceOffResult>(new Comparator<String>() {
            public int compare(String p1, String p2) {
                return _teamService.comparePositions(p1, p2);
            }
        });
         
        for (int i = 0; i < TConstants.MAIN_ROSTER_COUNT; i++) {
            Spieler p1 = team.getPlayers()[i];
            Spieler p2 = team2.getPlayers()[i];
            results.put(p1.getPosition(), faceOffLane(p1, p2));
        }
        
        boolean result = results.values().stream().filter(val -> val.getResult()).count() >= 3;
        
        if (numberOfTournaments < 10) {
            saveResultToFile(team, team2, boNumber, results, result);
        }
        
        // If at least 3 faceOffs returned true
        return result;
    }
    
    private void saveResultToFile(Team team, Team team2, int boNumber,  Map<String, FaceOffResult> results, boolean result) {
        double team1Elo = team.calculateAvgElo();
        double team2Elo = team2.calculateAvgElo();
        double eloDiff = team1Elo - team2Elo;
        
        StringBuilder sb = new StringBuilder();
        sb.append("Game: " + boNumber + "\n");
        sb.append("Participants: " + team.getTeamname() + " vs. " + 
                team2.getTeamname() + "\n");
        sb.append(team.getTeamname() + "'s Average Elo: " 
                + roundToDecimal(team1Elo, 3) + "\n");
        sb.append(team2.getTeamname() + "'s Average Elo: " 
                + roundToDecimal(team2Elo, 3) + "\n");
        sb.append("Team Elo Difference: " 
                + Double.toString(roundToDecimal(Math.abs(eloDiff), 3)) + "\n");
        
        for (Entry<String, FaceOffResult> entry : results.entrySet()) {
            FaceOffResult laneResult = entry.getValue();
            String team1Name = team.getTeamname();
            String team2Name = team2.getTeamname();
            
            sb.append(TConstants.INDENT);
            sb.append(entry.getKey() + ": ");
            sb.append(team1Name + " Winchance: "
                    + roundToDecimal(100 - laneResult.getProbability(), 3) + "% | ");
            sb.append(team2Name + " Winchance: "
                    + roundToDecimal(laneResult.getProbability(), 3) + "%");
            sb.append("  (" + ((laneResult.getResult()) ? team1Name : team2Name) + " win)");
            sb.append("  Lane Elo Difference was: " + laneResult.getEloDiff());
            sb.append("\n");
        }
        
        if(result)
        {
            sb.append("Winner: " + team.getTeamname());
        }
        else
        {
            sb.append("Winner: " + team2.getTeamname());
        }
        
        _handler.writeLog(sb.toString(), 0);
    }
    
    /**
     * Simulates a face of between two players.
     * 
     * @param player1 The first Player
     * @param player2 The second Player
     * 
     * @return The FaceOffResult
     */
    private FaceOffResult faceOffLane(Spieler player1, Spieler player2) {
        int player1Elo = player1.getElo().getEloAsInt();
        int player2Elo = player2.getElo().getEloAsInt();
        
        // The elo difference between the players.
        // Its higher, the lower the elo of player1 compared to the elo of player2
        double eloDiff = player1Elo - player2Elo;
        
        // The probability if both Teams have the same avg elo
        // The higher the higher the chances of win for team(1)
        double probability = 50;
        
        if(player1Elo < player2Elo)
        {
            probability += Math.pow(eloDiff * 1.3, 2);
        } 
        else if(player1Elo > player2Elo)
        {
            probability -= Math.pow(eloDiff * 1.3, 2);    
        }
        
        if(probability <= 0)
        {
            probability = 0.5;
        }
        else if (probability >= 100)
        {
            probability = 99.5;
        }
        
        boolean result = probability < ThreadLocalRandom.current().nextInt(0, 101);
        
        return new FaceOffResult(eloDiff, player1Elo, player2Elo, probability, result);
        
    }
    
    /**
     * Rounds a double to a defined number of digits.
     * 
     * @param d The Number that should be rounded
     * @param n The Number of Digits
     * 
     * @return The rounded double
     */
    private double roundToDecimal(double d, int n)
    {
        return Math.round(d * Math.pow(10, n)) / Math.pow(10, n);
    }
}
