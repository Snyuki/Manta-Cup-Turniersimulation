package de.manta.black.turniersim.services.model;

import de.manta.black.turniersim.ui.DisplayWinnerDialog;

/**
 * @version 27.12.2023
 * @author Jonas Müller
 *
 */
public class SimulationConfig
{
    /**
     * Shows if the Scroll Pane in the {@link DisplayWinnerDialog} is visible. <br>
     * True for not visible, False for visible. <br>
     * Default is false
     */
    private boolean scrollPaneToggled;

    /**
     * @return the scrollPaneToggled
     */
    public boolean getScrollPaneToggled()
    {
        return scrollPaneToggled;
    }

    /**
     * @param scrollPaneToggled the scrollPaneToggled to set
     */
    public void setScrollPaneToggled(boolean scrollPaneToggled)
    {
        this.scrollPaneToggled = scrollPaneToggled;
    }
    
    
    
}
