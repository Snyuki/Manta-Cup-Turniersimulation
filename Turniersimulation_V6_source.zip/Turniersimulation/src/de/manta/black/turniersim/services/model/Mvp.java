package de.manta.black.turniersim.services.model;

import de.manta.black.turniersim.materialien.Spieler;

/**
 * @version 20.12.2023
 * @author Jonas Müller
 *
 */
public class Mvp
{
    private Spieler spieler;
    private String team;
    
    /**
     * @return the spieler
     */
    public Spieler getSpieler()
    {
        return spieler;
    }

    /**
     * @return the team
     */
    public String getTeam()
    {
        return team;
    }

    /**
     * @param spieler the spieler to set
     */
    public void setSpieler(Spieler spieler)
    {
        this.spieler = spieler;
    }

    /**
     * @param team the team to set
     */
    public void setTeam(String team)
    {
        this.team = team;
    }
    
    
}
