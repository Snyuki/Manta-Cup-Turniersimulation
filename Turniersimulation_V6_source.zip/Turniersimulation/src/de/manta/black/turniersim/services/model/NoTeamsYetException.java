package de.manta.black.turniersim.services.model;

/**
 * An Exception that is thrown if there are no Teams
 * saved yet.
 * Will mostly occur on first start of the program.
 * 
 * @version 13.04.2022
 * @author Jonas Müller
 */
public class NoTeamsYetException extends Exception
{

    /**
     * Serial Id
     */
    private static final long serialVersionUID = -8488740433401363862L;
    
    /**
     * Default Constructor.
     */
    public NoTeamsYetException()
    {
        super();
    }
    
    /**
     * Constructor.
     * 
     * @param message The passed error message
     */
    public NoTeamsYetException(String message)
    {
        super(message);
    }

}
