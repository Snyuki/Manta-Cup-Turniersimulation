package de.manta.black.turniersim.services.model;

/**
 * @version 20.12.2023
 * @author Jonas Müller
 *
 */
public class FaceOffResult
{
    private double eloDiff;
    private int player1Elo;
    private int player2Elo;
    private double probability;
    private boolean result;
    
    /**
     * @param eloDiff The Elo diff between player1 and player2
     * @param player1Elo The Elo of player1
     * @param player2Elo The Elo of player2
     * @param probability The win probability (the lower the better for player1)
     * @param result The result of the face off
     */
    public FaceOffResult(double eloDiff, int player1Elo, int player2Elo,
            double probability, boolean result)
    {
        this.eloDiff = eloDiff;
        this.player1Elo = player1Elo;
        this.player2Elo = player2Elo;
        this.probability = probability;
        this.result = result;
    }

    /**
     * @return the eloDiff
     */
    public double getEloDiff()
    {
        return eloDiff;
    }

    /**
     * @return the player1Elo
     */
    public int getPlayer1Elo()
    {
        return player1Elo;
    }

    /**
     * @return the player2Elo
     */
    public int getPlayer2Elo()
    {
        return player2Elo;
    }

    /**
     * @return the probability
     */
    public double getProbability()
    {
        return probability;
    }

    /**
     * @return the result
     */
    public boolean getResult()
    {
        return result;
    }
    
    
}