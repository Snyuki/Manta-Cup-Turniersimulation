package de.manta.black.turniersim.ui;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import de.manta.black.turniersim.materialien.Spieler;
import de.manta.black.turniersim.materialien.Team;
import de.manta.black.turniersim.services.model.EloRanking;

/**
 * A Panel that includes all elements on the TeamTab.
 * It mostly consists of JPositionPanels.
 * 
 * @version 07.04.2022
 * @author Jonas Müller
 *
 */
public class JTeamPanel extends JPanel
{
    private static final String AVG_ELO_STRING = "Average Team Elo: ";
    
    private static double _calculatedElo;

    private JLabel _name;
    private JLabel _elo;
    private JLabel _avgElo;

    private JTextField _teamNameField;
    
    private JButton _save;
    
    private JPositionPanel _topPanel;
    private JPositionPanel _jnglPanel;
    private JPositionPanel _midPanel;
    private JPositionPanel _adcPanel;
    private JPositionPanel _suppPanel;

    private JPanel _teamNamePanel;
    private JPanel _footerPanel;
    private JPanel _headerPanel;
    
    /**
     * Serial ID
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor
     */
    public JTeamPanel()
    {
        initPanel();
        initSubPanels();
    }

    /**
     * Initializes the SubPanels
     */
    private void initSubPanels()
    {
        _teamNamePanel = new JPanel();
        _teamNamePanel.setLayout(new FlowLayout());
        _teamNameField = new JTextField();
        _teamNameField.setColumns(25);
        _teamNamePanel.add(_teamNameField);
        
        _headerPanel = new JPanel();
        _headerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 140, 0));
        _name = new JLabel("Summoner-Name");
        _headerPanel.add(_name);
        _elo = new JLabel("Elo");
        _headerPanel.add(_elo);
        
        _footerPanel = new JPanel();
        _footerPanel.setLayout(new FlowLayout());
        _avgElo = new JLabel(AVG_ELO_STRING + _calculatedElo);
        _footerPanel.add(_avgElo);
        _save = new JButton("Save");
        _footerPanel.add(_save);
        
        _topPanel = new JPositionPanel("Top");
        _jnglPanel = new JPositionPanel("Jungle");
        _midPanel = new JPositionPanel("Mid");
        _adcPanel = new JPositionPanel("Adc");
        _suppPanel = new JPositionPanel("Support");
        
        add(_teamNamePanel);
        add(_headerPanel);
        add(_topPanel);
        add(_jnglPanel);
        add(_midPanel);
        add(_adcPanel);
        add(_suppPanel);
        add(_footerPanel);

    }

    /**
     * Initializes the Team Panel
     */
    private void initPanel()
    {
        setLayout(new GridLayout(0, 1));
        _calculatedElo = 0;
    }
    
    /**
     * Sets the avg Elo of the Team.
     * 
     * @param calculatedElo The avg Elo
     */
    public void setAvgElo(double calculatedElo)
    {
       getAvgEloLabel().setText(AVG_ELO_STRING + calculatedElo);
    }

    /**
     * @return the avgEloLabel
     */
    public JLabel getAvgEloLabel()
    {
        return _avgElo;
    }

    /**
     * @return the topPanel
     */
    public JPositionPanel getTopPanel()
    {
        return _topPanel;
    }
    
    /**
     * @return the jnglPanel
     */
    public JPositionPanel getJnglPanel()
    {
        return _jnglPanel;
    }
    
    /**
     * @return the midPanel
     */
    public JPositionPanel getMidPanel()
    {
        return _midPanel;
    }
    
    /**
     * @return the adcPanel
     */
    public JPositionPanel getAdcPanel()
    {
        return _adcPanel;
    }
    
    /**
     * @return the suppPanel
     */
    public JPositionPanel getSuppPanel()
    {
        return _suppPanel;
    }
    
    /**
     * @return the teamNameField
     */
    public JTextField getTeamNameField()
    {
        return _teamNameField;
    }

    /**
     * @return the save Button
     */
    public JButton getSave()
    {
        return _save;
    }
    
    /**
     * @param teamNameField the teamNameField to set
     */
    public void setTeamNameField(JTextField teamNameField)
    {
        this._teamNameField = teamNameField;
    }

    /**
     * Returns an Array of Strings with the Elos of the Team
     * ordered from Top to Bot to Sub1 to Sub3.
     * 
     * @return An Array of the Elos
     */
    public String[] getElos()
    {
        String[] elos = new String[5];
        elos[0] = ((EloRanking) getTopPanel().getEloComboBox().getSelectedItem()).getEloAsString();
        elos[1] = ((EloRanking) getJnglPanel().getEloComboBox().getSelectedItem()).getEloAsString();
        elos[2] = ((EloRanking) getMidPanel().getEloComboBox().getSelectedItem()).getEloAsString();
        elos[3] = ((EloRanking) getAdcPanel().getEloComboBox().getSelectedItem()).getEloAsString();
        elos[4] = ((EloRanking) getSuppPanel().getEloComboBox().getSelectedItem()).getEloAsString();
        return elos;
    }
    
    /**
     * Returns an Array of Strings with the Summoner Names of the Team
     * ordered from Top to Bot to Sub1 to Sub3.
     * 
     * @return An Array of the Summoner Names
     */
    public String[] getNames()
    {
        String[] names = new String[5];
        names[0] = getTopPanel().getNameField().getText();
        names[1] = getJnglPanel().getNameField().getText();
        names[2] = getMidPanel().getNameField().getText();
        names[3] = getAdcPanel().getNameField().getText();
        names[4] = getSuppPanel().getNameField().getText();
        return names;
    }
    
    /**
     * Fills the Teamfields with the passed values.
     * 
     * @param team The Team that is to be filled
     * 
     * @throws IllegalArgumentException If the players position isnt valid
     * @throws NullPointerException If the team was null
     */
    public void fillTeamData(Team team) throws IllegalArgumentException, NullPointerException
    {
        getTeamNameField().setText(team.getTeamname());
        
        for(Spieler player : team.getPlayers())
        {
            if(player == null)
            {
                continue;
            }
            switch (player.getPosition())
            {
            case "Top":
            {
                getTopPanel().getNameField().setText(player.getPlayerName());
                getTopPanel().getEloComboBox().setSelectedItem(player.getElo());
                break;
            }
            case "Jngl":
            {
                getJnglPanel().getNameField().setText(player.getPlayerName());
                getJnglPanel().getEloComboBox().setSelectedItem(player.getElo());
                break;
            }
            case "Mid":
            {
                getMidPanel().getNameField().setText(player.getPlayerName());
                getMidPanel().getEloComboBox().setSelectedItem(player.getElo());
                break;
            }
            case "Adc":
            {
                getAdcPanel().getNameField().setText(player.getPlayerName());
                getAdcPanel().getEloComboBox().setSelectedItem(player.getElo());
                break;
            }
            case "Supp":
            {
                getSuppPanel().getNameField().setText(player.getPlayerName());
                getSuppPanel().getEloComboBox().setSelectedItem(player.getElo());
                break;
            }
            default:
                throw new IllegalArgumentException("Unexpected value: " + player.getPosition());
            }
        }
    }
}
