package de.manta.black.turniersim.ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import de.manta.black.turniersim.materialien.Spieler;
import de.manta.black.turniersim.materialien.Team;
import de.manta.black.turniersim.services.FileHandler;
import de.manta.black.turniersim.services.model.EloRanking;
import de.manta.black.turniersim.werkzeuge.TConstants;

/**
 * The Main Window of the Application.
 * 
 * @version 07.04.2022
 * @author Jonas Müller
 *
 */
public class Window
{
    // The Frame
    private static JFrame _frame;
    private static JTabbedPane _mainPane;
    
    private static JTeamPanel[] _teamPanels;
    private static JSimulationPanel _simulationPanel;
    
    private final FileHandler _fileHandler;
    
    /**
     * Constructor.
     * 
     * @param fileHandler The file handler of the program
     */
    public Window(FileHandler fileHandler)
    {
        _fileHandler = fileHandler;
        
        initFrame();
        initPane();
        initPanels();
    }

    /**
     * Calculates the Elo of a Team
     * 
     * @param elos An Array of all the Elos
     * 
     * @return The Avg Elo
     * 
     * @throws NumberFormatException If entered value is not a number
     */
    public double calculateAvgElo(String[] elos) throws NumberFormatException
    {
        double summedElos = 0;
        double eloCount = 0;
        
        for (String elo : elos)
        {
            if(elo.isEmpty())
            {
                continue;
            }
            try
            {
                summedElos += Integer.parseInt(elo);
                eloCount++;
            }
            catch (NumberFormatException e) 
            {
                throw new NumberFormatException("Please enter only Numbers!");
            }
        }
        return summedElos / eloCount;
    }

    /**
     * Initializes the Panels within the Frame.
     */
    private void initPanels()
    {
        _teamPanels = new JTeamPanel[12];
        
        for(int i = 0; i < 12; i++)
        {
            _teamPanels[i] = new JTeamPanel();
            _mainPane.add("Team " + (i + 1), _teamPanels[i]);
        }
        
        _simulationPanel = new JSimulationPanel();
        _mainPane.add("Simulation", _simulationPanel);
    }

    /**
     * Initializes the Pane for the Frame
     */
    private void initPane()
    {
        _mainPane = new JTabbedPane();
        _frame.add(_mainPane);
    }
    
    /**
     * Initializes the Frame without content.
     */
    private void initFrame()
    {
        _frame = new JFrame("Turniersimulation Manta Cup v" + TConstants.APP_VERSION);
        _frame.setSize(900, 700);
        _frame.setLocationRelativeTo(null);
//        _frame.setLayout(new BorderLayout());
        _frame.setDefaultCloseOperation(3);
    }
    
    /**
     * Updates the Team Panels
     */
    public void updateTeamPanels() {
        for (int i = 0; i < getTeamPanels().length; i++)
        {
            JTeamPanel teamPanel = getTeamPanels()[i];
            double avgElo = calculateAvgElo(teamPanel.getElos());
            teamPanel.setAvgElo(avgElo);
            String teamName = teamPanel.getTeamNameField().getText();
            if (!teamName.isBlank()) {
                this.getMainPane().setTitleAt(i, teamName);
            }
            else
            {
                this.getMainPane().setTitleAt(i, "Team " + (i + 1));
            }
        }
    }
    
    /**
     * Returns the Teams 1-12 created from the twelve Team
     * Panels where the Data was filled in.
     * 
     * @return An Array with the Teams
     */
    public Team[] getTeams()
    {
        Team[] teams = new Team[12];
        
        for(int i = 0; i < getTeamPanels().length; i++)
        {
            String teamName = getTeamPanels()[i].getTeamNameField().getText();
            Spieler[] players = new Spieler[TConstants.TEAM_SIZE];
            
            // XXX Refactor
            players[0] = new Spieler(getTeamPanels()[i].getTopPanel().getNameField().getText(), 
                    ((EloRanking) getTeamPanels()[i].getTopPanel().getEloComboBox().getSelectedItem()).getEloAsInt(), TConstants.TOP);
            players[1] = new Spieler(getTeamPanels()[i].getJnglPanel().getNameField().getText(),
                    ((EloRanking) getTeamPanels()[i].getJnglPanel().getEloComboBox().getSelectedItem()).getEloAsInt(), TConstants.JNGL);
            players[2] = new Spieler(getTeamPanels()[i].getMidPanel().getNameField().getText(), 
                    ((EloRanking) getTeamPanels()[i].getMidPanel().getEloComboBox().getSelectedItem()).getEloAsInt(), TConstants.MID);
            players[3] = new Spieler(getTeamPanels()[i].getAdcPanel().getNameField().getText(),
                    ((EloRanking) getTeamPanels()[i].getAdcPanel().getEloComboBox().getSelectedItem()).getEloAsInt(), TConstants.ADC);
            players[4] = new Spieler(getTeamPanels()[i].getSuppPanel().getNameField().getText(),
                    ((EloRanking) getTeamPanels()[i].getSuppPanel().getEloComboBox().getSelectedItem()).getEloAsInt(), TConstants.SUPP);
            
            // XXX Show Window with assertion error -> If team is null
            teams[i] = new Team(players, teamName);
        }
        
        return teams;
    }

    /**
     * Changes the visiblitiy of the Frame to true.
     */
    public void showFrame()
    {
        _frame.setVisible(true);
    }
    
    /**
     * @return the simulateButton
     */
    public JButton getSimulateButton()
    {
        return _simulationPanel.getSimulateButton();
    }
    
    /**
     * @return the multiSimulateButton
     */
    public JButton getMultiSimulateButton()
    {
        return _simulationPanel.getMultiSimulateButton();
    }
    
    /**
     * @return the clearLogButton
     */
    public JButton getClearLogButton()
    {
        return _simulationPanel.getClearLogButton();
    }
    
    /**
     * @return the showLogButton
     */
    public JButton getShowLogButton()
    {
        return _simulationPanel.getShowLogButton();
    }

    /**
     * @return the teamPanels
     */
    public JTeamPanel[] getTeamPanels()
    {
        return _teamPanels;
    }

    /**
     * @return the mainPane
     */
    public JTabbedPane getMainPane()
    {
        return _mainPane;
    }
    
    /**
     * @return the frame
     */
    public JFrame getFrame()
    {
        return _frame;
    }
    
    /**
     * Sets up the Team Panels with the data from the passed Team Array.
     * 
     * @param teams The Team array
     * 
     * @require teams.length == 12
     */
    public void setUpTeams(Team[] teams)
    {
        assert teams.length == 12 : "(setUpTeams) Vorbedingung verletzt: teams.length == 12";
        
        JTeamPanel[] teamPanels = getTeamPanels();
        
        for(int i = 0; i < teamPanels.length; i++)
        {
            try
            {
                teamPanels[i].fillTeamData(teams[i]);                
            }
            catch (NullPointerException e)
            {
                _fileHandler.writeErrorLog("Team position was null. Ignore if first execution.", null);
            }
            catch (IllegalArgumentException e)
            {
                String errorMsg = "A players position was not valid!";
                System.out.println(errorMsg);
                _fileHandler.writeErrorLog(errorMsg, e);
            }
        }
    }
    
    /**
     * Updates the Bracket Tables.
     * 
     * @param simulatedLB The simulated Upper Bracket
     * @param simulatedUB The simulated Lower Bracket
     */
    public void updateBrackets(Team[] simulatedUB, Team[] simulatedLB)
    {
        _simulationPanel.updateBrackets(simulatedUB, simulatedLB);
    }
    
    /**
     * Updates the Playoff Tree acording to the participants.
     * 
     * @param quarterParticipants The Team participating in the quarterfinals
     * @param quarterTeams The Teams winning the quarterfinals
     * @param semisTeams The Teams winning the semifinals
     * @param thirdPlaceWinner The Team that won the third place match
     * @param finalTeam The Team winning the finals
     */
    public void updatePlayoffTree(Team[] quarterParticipants, Team[] quarterTeams, Team[] semisTeams, Team thirdPlaceWinner, Team finalTeam)
    {
        _simulationPanel.updatePlayoffTree(quarterParticipants, quarterTeams, semisTeams, thirdPlaceWinner, finalTeam);
    }
    
}
