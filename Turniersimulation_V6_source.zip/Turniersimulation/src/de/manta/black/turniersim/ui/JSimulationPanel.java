package de.manta.black.turniersim.ui;

import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import de.manta.black.turniersim.materialien.Team;

/**
 * A Panel for the visualization of the Tounamentsimulation.
 * 
 * @version 08.04.2022
 * @author Jonas Müller
 *
 */
public class JSimulationPanel extends JPanel
{

    /**
     * Generated Serial ID
     */
    private static final long serialVersionUID = 4876092391847694695L;

    private static final String[] COLUMN_HEADERS = new String[] {"Placement", "Team"};
    private String[][] _upperRowData = new String[6][2];
    private String[][] _lowerRowData = new String[6][2];
    
    private JPanel _bracketPanel;
    private JPanel _playoffPanel;
    
    private JTable _ubTable;
    private JTable _lbTable;
    
    private JLabel _bracketLabel;

    private JTextField[] _participantsLabels;
    private JTextField[] _quartersLabels;
    private JTextField[] _semisLabels;
    private JTextField _thirdPlaceLabel;
    private JTextField _finalsLabel;
    
    private JButton _simulateButton;
    private JButton _multiSimulateButton;
    private JButton _clearLogButton;
    private JButton _showLogButton;
    
    
    /**
     * Constructor.
     * 
     */
    public JSimulationPanel()
    {
        initPanel();
        createBracketPanel();
        createPlayoffPanel();
    }

    /**
     * Creates the Playoff Panel
     */
    private void createPlayoffPanel()
    {
        _playoffPanel = new JPanel();
        _playoffPanel.setLayout(new GridLayout(2, 1));
        
        _playoffPanel.add(createPlayoffTreePanel());
        
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1));
        
        JPanel simulatePanel = new JPanel();
        _simulateButton = new JButton("Simulate");
        simulatePanel.add(_simulateButton);
        _multiSimulateButton = new JButton("Multi Simulate");
        simulatePanel.add(_multiSimulateButton);
        
        JPanel logPanel = new JPanel();
        _clearLogButton = new JButton("Clear Log");
        logPanel.add(_clearLogButton);
        _showLogButton = new JButton("Show Log");
        logPanel.add(_showLogButton);
        
        buttonPanel.add(simulatePanel);
        buttonPanel.add(logPanel);
        _playoffPanel.add(buttonPanel);
        
        add(_playoffPanel);
    }
    
    /**
     * Creates the Playoff Tree visulaization Panel.
     * 
     * @return The Playoff visulaization Panel
     */
    private JPanel createPlayoffTreePanel()
    {
        setUpTextFields();
        JPanel treePanel = new JPanel();
        treePanel.setLayout(new GridLayout(4, 1));
        
        // Participants
        JPanel participantsPanel = new JPanel(new GridLayout(2, 4));
        for(JTextField tag : _participantsLabels)
        {
            JPanel subPanel = new JPanel();
            subPanel.add(tag);
            participantsPanel.add(subPanel);
        }
        treePanel.add(participantsPanel);
        
        // Quarters
        JPanel quartersPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 50));
        for(JTextField tag : _quartersLabels)
        {
            quartersPanel.add(tag);
        }
        treePanel.add(quartersPanel);

        // Semis
        JPanel semisPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 100, 25));
        for(JTextField tag : _semisLabels)
        {
            semisPanel.add(tag);
        }
        treePanel.add(semisPanel);
        
        // Finals
        JPanel finalsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        finalsPanel.add(new JLabel("Winner: "));
        finalsPanel.add(_finalsLabel);
        finalsPanel.add(new JLabel("Third Place: "));
        finalsPanel.add(_thirdPlaceLabel);
        treePanel.add(finalsPanel);
        
        return treePanel;
    }

    /**
     * Initializes the Labels for the TreePanel.
     */
    private void setUpTextFields()
    {
        _participantsLabels = new JTextField[8];
        _quartersLabels = new JTextField[4];
        _semisLabels = new JTextField[2];
        
        for(int i = 0; i < 8; i++)
        {
            _participantsLabels[i] = createCustomTextField("");
            if(i < 4) _quartersLabels[i] = createCustomTextField("");
            if(i < 2) _semisLabels[i] = createCustomTextField("");
            if(i < 1) 
            {
                _finalsLabel = createCustomTextField("");
                _thirdPlaceLabel = createCustomTextField("");
            }
        }  
    }
    
    /**
     * Creates a custom Textfield suitable for the context.
     * 
     * @return The TextField
     */
    private JTextField createCustomTextField(String teamName)
    {
        JTextField tag = new JTextField(teamName);
        tag.setEditable(false);
        tag.setHorizontalAlignment(JTextField.CENTER);
        tag.setColumns(8);
        return tag;
    }

    /**
     * Creates the Bracketpanel which is positioned on the left side of the
     * Tab.
     */
    private void createBracketPanel()
    {
        _bracketPanel = new JPanel();
        _bracketPanel.setLayout(new GridLayout(0, 1));
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 50));
        _bracketLabel = new JLabel("Brackets");
        headerPanel.add(_bracketLabel);
        _bracketPanel.add(headerPanel);
        
        // Upper Bracket Table
        _ubTable = new JTable(_upperRowData, COLUMN_HEADERS);
        _ubTable.setEnabled(false);
        _bracketPanel.add(new JScrollPane(_ubTable));
        
        // Lower Bracket Tabel
        _lbTable = new JTable(_lowerRowData, COLUMN_HEADERS);
        _lbTable.setEnabled(false);
        _bracketPanel.add(new JScrollPane(_lbTable));
        
        add(_bracketPanel);
    }

    /**
     * Initializes the Panel.
     */
    private void initPanel()
    {
        setLayout(new GridLayout(1, 2));
    }
    
    
    /**
     * Updates the Bracket Tables
     * 
     * @param simulatedLB The simulated Upper Bracket
     * @param simulatedUB The simulated Lower Bracket
     */
    public void updateBrackets(Team[] simulatedUB, Team[] simulatedLB)
    {
        for(int i = 0; i < simulatedUB.length; i++)
        {
            _upperRowData[i] = new String[] {i + 1 + "", simulatedUB[i].getTeamname()};
            _lowerRowData[i] = new String[] {i + 1 + "", simulatedLB[i].getTeamname()};
        }
        
        _ubTable.repaint();
        _lbTable.repaint();
    }

    /**
     * @return the simulateButton
     */
    public JButton getSimulateButton()
    {
        return _simulateButton;
    }
    
    /**
     * @return the multiSimulateButton
     */
    public JButton getMultiSimulateButton()
    {
        return _multiSimulateButton;
    }
    
    /**
     * @return the clearLogButton
     */
    public JButton getClearLogButton()
    {
        return _clearLogButton;
    }
    
    /**
     * @return the showLogButton
     */
    public JButton getShowLogButton()
    {
        return _showLogButton;
    }
    
    /**
     * Updates the Quarters Participants.
     * 
     * @param quarterTeams the quarters participants
     */
    private void setParticipantsLabels(Team[] quarterParticipants)
    {
        for(int i = 0; i < quarterParticipants.length; i++)
        {
            _participantsLabels[i].setText(quarterParticipants[i].getTeamname());
        }
    }

    /**
     * Updates the Quarters Winners.
     * 
     * @param quarterTeams the quarters winners
     */
    private void setQuartersLabels(Team[] quarterTeams)
    {
        for(int i = 0; i < _quartersLabels.length; i++)
        {
            _quartersLabels[i].setText(quarterTeams[i].getTeamname());
        }
    }

    /**
     * Updates the Semis Winner.
     * 
     * @param semisTeams the semis winners
     */
    private void setSemisLabels(Team[] semisTeams)
    { 
        for(int i = 0; i < _semisLabels.length; i++)
        {
            _semisLabels[i].setText(semisTeams[i].getTeamname());
        }
    }

    /**
     * Updates the Third Place Winner.
     * 
     * @param thirdPlacedTeam the team that won the match for the third place
     */
    private void setThirdPlaceLabel(Team thirdPlacedTeam)
    {
        _thirdPlaceLabel.setText(thirdPlacedTeam.getTeamname());
    }
    
    /**
     * Updates the Finals Winner.
     * 
     * @param finalTeam the finals winner
     */
    private void setFinalsLabel(Team finalTeam)
    {
        _finalsLabel.setText(finalTeam.getTeamname());
    }
    
    
    /**
     * Updates the Playoff Tree acording to the participants.
     * 
     * @param quarterParticipants The Team participating in the quarterfinals
     * @param quarterTeams The Teams winning the quarterfinals
     * @param semisTeams The Teams winning the semifinals
     * @param thirdPlaceWinner The Team that won the third place match
     * @param finalTeam The Team winning the finals
     */
    public void updatePlayoffTree(Team[] quarterParticipants, Team[] quarterTeams, Team[] semisTeams, Team thirdPlaceWinner, Team finalTeam)
    {
        setParticipantsLabels(quarterParticipants);
        setQuartersLabels(quarterTeams);
        setSemisLabels(semisTeams);
        setThirdPlaceLabel(thirdPlaceWinner);
        setFinalsLabel(finalTeam);
        _playoffPanel.repaint();
    }

}
