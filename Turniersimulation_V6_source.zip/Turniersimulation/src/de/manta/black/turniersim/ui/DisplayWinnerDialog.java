package de.manta.black.turniersim.ui;

import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.math.BigInteger;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import de.manta.black.turniersim.materialien.Team;
import de.manta.black.turniersim.services.ConfigService;

/**
 * This Class displayes the current winner of a simulated Torunament
 * in a constantly updating Dialog.
 * 
 * @version 15.04.2022
 * @author Jonas Müller
 */
public class DisplayWinnerDialog extends JDialog
{
    
    /**
     * Serial Id
     */
    private static final long serialVersionUID = 1L;

    private static final String[] COLUMN_NAMES = new String[] {"Iteration", "Winner"};
    
    private ConfigService _configService;
    
    private long _startTime;
    
    private long _currentIteration;
    private long _totalIterations;
    
    private JTable _winnersTable;
    private DefaultTableModel _tableModel;
    private JScrollPane _scrollPane;
    
    private JProgressBar _progressBar;

    private JCheckBox _toggleTableCheckbox;
    
    private JButton _stopDialogButton;
    private JButton _closeDialogButton;

    private JLabel _remainingTimeLabelInfo;
    private JLabel _remainingTimeLabel;
    
    /**
     * Constructor.
     * 
     * @param parentFrame The Parent Frame of the Dialog
     * @param iterations The total number of simulations
     * @param configService The Application Configuration Service
     */
    public DisplayWinnerDialog(JFrame parentFrame, long iterations, ConfigService configService)
    {
        super(parentFrame, "Simulating " + iterations + " Tournaments", true);
        
        _startTime = System.nanoTime();
        _currentIteration = 0;
        _totalIterations = iterations;
        _configService = configService;
        
        setUpFrame();
    }
    
    /**
     * Sets up the Frame for the display of the winners.
     */
    private void setUpFrame()
    {
        this.setBounds(300, 300, 300, 200);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());

        _tableModel = new DefaultTableModel();
        _tableModel.setColumnIdentifiers(COLUMN_NAMES);
        _winnersTable = new JTable((_configService.getConfig().getScrollPaneToggled()) ? null : _tableModel);
        _winnersTable.setEnabled(false);
        
        _scrollPane = new JScrollPane(_winnersTable);
        tablePanel.add(_scrollPane, BorderLayout.CENTER);
        
        JPanel southPanel = new JPanel(new BorderLayout());
        
        _progressBar = new JProgressBar();
        _progressBar.setValue(0);
        _progressBar.setStringPainted(true);
        southPanel.add(_progressBar, BorderLayout.NORTH);
        
        JPanel checkBoxTimePanel = new JPanel(new BorderLayout());
        
        _toggleTableCheckbox = new JCheckBox("Toggle Table");
        _toggleTableCheckbox.setSelected(_configService.getConfig().getScrollPaneToggled());
        checkBoxTimePanel.add(_toggleTableCheckbox, BorderLayout.NORTH);
        
        _remainingTimeLabelInfo = new JLabel("Estimated remaining time: ");
        checkBoxTimePanel.add(_remainingTimeLabelInfo, BorderLayout.WEST);

        _remainingTimeLabel = new JLabel("");
        checkBoxTimePanel.add(_remainingTimeLabel, BorderLayout.EAST);
        
        southPanel.add(checkBoxTimePanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel();
        _stopDialogButton = new JButton("Stop");
        buttonPanel.add(_stopDialogButton);
        _closeDialogButton = new JButton("Close");
        buttonPanel.add(_closeDialogButton);
        southPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        tablePanel.add(southPanel, BorderLayout.SOUTH);
        
        this.getContentPane().add(tablePanel);
    }
    
    /**
     * Adds a winner to the representation and updates the table.
     * Deletes the first entry (FIFO) if the entry length is higher than
     * a certain value.
     * 
     * @param winner The winner of the tournament
     */
    public void addWinner(Team winner)
    {   
            _tableModel.addRow(new Object[] {(_currentIteration + 1) + ".", winner.getTeamname()});
            this._currentIteration++;
            
            if (_currentIteration % 3000 == 0) {
                updateProgressBar();
                updateRemainingTime();
                if (_scrollPane.isVisible()) scrollToEnd();
            }
    }

    /**
     * Scrolls to the end of the scoll pane
     */
    public void scrollToEnd()
    {
        int lastRow = _winnersTable.getModel().getRowCount() - 1;
        Rectangle r = _winnersTable.getCellRect(lastRow, 0, true);
        _winnersTable.scrollRectToVisible(r);
    }
    
    /**
     * Updates the Progress Bar
     */
    public void updateProgressBar() {
        double progress = (double) _currentIteration / (double) _totalIterations * 100;
        _progressBar.setValue((int) (progress));
    }
    
    /**
     * Updates the estimated remaining time
     */
    public void updateRemainingTime() {
        Long elapsedTime = System.nanoTime() - _startTime;
        Long allTimeForDownloading = (BigInteger.valueOf(elapsedTime)
                .multiply(BigInteger.valueOf(_totalIterations))
                .divide(BigInteger.valueOf(_currentIteration))).longValue();
        Long remainingTime = allTimeForDownloading - elapsedTime;

        this._remainingTimeLabel
            .setText(String.format("%02d:%02d:%02d", 
                TimeUnit.NANOSECONDS.toHours(remainingTime),
                TimeUnit.NANOSECONDS.toMinutes(remainingTime) -  
                TimeUnit.HOURS.toMinutes(TimeUnit.NANOSECONDS.toHours(remainingTime)),
                TimeUnit.NANOSECONDS.toSeconds(remainingTime) - 
                TimeUnit.MINUTES.toSeconds(TimeUnit.NANOSECONDS.toMinutes(remainingTime)))      // TODO check if correct / large iter -> Time increases
            );
    }
    
    /**
     * Removes all rows from the table model.
     */
    public void removeAllRows()
    {
        _tableModel.setRowCount(0);
    }
    
    /**
     * Returns the Close Dialog Button
     * 
     * @return The close Button
     */
    public JButton getCloseButton()
    {
        return _closeDialogButton;
    }
    
    /**
     * Returns the Stop Dialog Button
     * 
     * @return The Stop Button
     */
    public JButton getStopButton()
    {
        return _stopDialogButton;
    }
    
    /**
     * Returns the Toggle Table Checkbox
     * 
     * @return The Toggle Table Checkbox
     */
    public JCheckBox getToggleTableCheckbox()
    {
        return _toggleTableCheckbox;
    }
    
    /**
     * Returns the Scroll Pane
     * 
     * @return The Scroll Pane
     */
    public JScrollPane get_scrollPane()
    {
        return _scrollPane;
    }

    /**
     * Returns the Dialog.
     * 
     * @return The dialog
     */
    public JDialog getDialog()
    {
        return this;
    }
    
    /**
     * Opens the Window
     */
    public void openWindow()
    {
        this.repaint();
        this.setVisible(true);
    }
    
    /**
     * Closes the Window
     */
    public void closeWindow()
    {
        _configService.getConfig().setScrollPaneToggled(_toggleTableCheckbox.isSelected());
        this.dispose();
    }
    
    /**
     * Toggles the visibility of the scroll pane.
     * 
     * @param status The to be visibility of the scroll pane
     */
    public void toggleScrollPane(boolean status)
    {
        if (status)
        {
            this._winnersTable.setModel(_tableModel);
        }
        else
        {
            this._winnersTable.setModel(new DefaultTableModel());
        }
        
        this.repaint();
    }
}
