package de.manta.black.turniersim.ui;

import java.awt.FlowLayout;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import de.manta.black.turniersim.services.model.EloRanking;

/**
 * A Panel that combines a Label with the given Position,
 * a TextField for the Name and one for the Elo in a FlowLayout.
 * 
 * @version 07.04.2022
 * @author Jonas Müller
 *
 */
public class JPositionPanel extends JPanel
{
    
    /**
     * Generated ID
     */
    private static final long serialVersionUID = -2842134547248295511L;

    private static String POSITION;

    private JLabel _positionLabel;
    private JTextField _nameField;
    private JComboBox<EloRanking> _eloComboBox;
    
    /**
     * Constructor
     * 
     * @param position The Position of the Player
     */
    public JPositionPanel(String position)
    {
        POSITION = position;
        initPanel();
        initComponents();
    }

    /**
     * Initializes the Components
     */
    private void initComponents()
    {
        _positionLabel = new JLabel(POSITION + ":");
        add(_positionLabel);
        _nameField = new JTextField();
        _nameField.setColumns(20);
        add(_nameField);
        _eloComboBox = new JComboBox<EloRanking>(EloRanking.values());
        add(_eloComboBox);
    }

    /**
     * Initialize the Panel
     */
    private void initPanel()
    {
        setLayout(new FlowLayout());
    }

    /**
     * @return the nameField
     */
    public JTextField getNameField()
    {
        return _nameField;
    }

    /**
     * @return the eloField
     */
    public JComboBox<EloRanking> getEloComboBox()
    {
        return _eloComboBox;
    }

    /**
     * @param nameField the nameField to set
     */
    public void setNameField(JTextField nameField)
    {
        this._nameField = nameField;
    }

    /**
     * @param eloField the eloField to set
     */
    public void setEloField(JComboBox<EloRanking> eloComboBox)
    {
        this._eloComboBox = eloComboBox;
    }
    
    
        
}
